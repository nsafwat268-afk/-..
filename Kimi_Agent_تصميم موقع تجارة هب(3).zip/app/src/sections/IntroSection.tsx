import { TrendingUp, Globe, Award, Leaf } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

const exportData = [
  { name: 'الفراولة المجمدة', value: 383, color: '#FF6B35' },
  { name: 'الموالح', value: 520, color: '#F7931E' },
  { name: 'الخضروات المجمدة', value: 241, color: '#FDB833' },
  { name: 'البطاطس المقلية', value: 180, color: '#FFC857' },
];

const topExporters = [
  { country: 'ألمانيا', value: 41.8, flag: '🇩🇪' },
  { country: 'الصين', value: 41.9, flag: '🇨🇳' },
  { country: 'بولندا', value: 30.5, flag: '🇵🇱' },
  { country: 'روسيا', value: 262, flag: '🇷🇺' },
  { country: 'السعودية', value: 172, flag: '🇸🇦' },
];

export default function IntroSection() {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-eden-dark via-eden-dark to-eden-orange p-8 md:p-12">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-eden-orange rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-eden-gold rounded-full blur-3xl transform -translate-x-1/2 translate-y-1/2" />
        </div>
        
        <div className="relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm mb-6">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-white/80 text-sm">خطة تصدير احترافية 2025</span>
          </div>
          
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
            خطة التصدير الاستراتيجية
          </h1>
          <h2 className="text-2xl md:text-3xl font-bold eden-text-gradient mb-6">
            شركة إيدن جاردن - Eden Garden
          </h2>
          
          <p className="text-white/70 max-w-3xl mx-auto text-lg leading-relaxed">
            في خضم التحولات الجيوسياسية والاقتصادية التي تشهدها سلاسل الإمداد الغذائي العالمية، 
            تبرز مصر كلاعب محوري في قطاع الحاصلات الزراعية المصنعة والطازجة، 
            مدعومة بميزة تنافسية جغرافية ومناخية فريدة.
          </p>
        </div>
      </div>

      {/* Key Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="eden-card p-6 text-center hover:shadow-eden-lg transition-shadow">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-3xl font-bold eden-text-gradient">6.1 مليار</h3>
          <p className="text-gray-600 text-sm mt-2">دولار صادرات مصر الغذائية 2024</p>
          <span className="inline-block mt-2 px-3 py-1 rounded-full bg-green-100 text-green-600 text-xs font-medium">
            +21% نمو سنوي
          </span>
        </div>

        <div className="eden-card p-6 text-center hover:shadow-eden-lg transition-shadow">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-amber to-eden-gold flex items-center justify-center mx-auto mb-4">
            <Globe className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-3xl font-bold eden-text-gradient">27.1%</h3>
          <p className="text-gray-600 text-sm mt-2">حصة مصر العالمية في الفراولة المجمدة</p>
          <span className="inline-block mt-2 px-3 py-1 rounded-full bg-blue-100 text-blue-600 text-xs font-medium">
            المرتبة الأولى عالمياً
          </span>
        </div>

        <div className="eden-card p-6 text-center hover:shadow-eden-lg transition-shadow">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-gold to-eden-yellow flex items-center justify-center mx-auto mb-4">
            <Award className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-3xl font-bold eden-text-gradient">3.6%</h3>
          <p className="text-gray-600 text-sm mt-2">حصة مصر في الخضروات المجمدة عالمياً</p>
          <span className="inline-block mt-2 px-3 py-1 rounded-full bg-purple-100 text-purple-600 text-xs font-medium">
            المرتبة الرابعة عالمياً
          </span>
        </div>

        <div className="eden-card p-6 text-center hover:shadow-eden-lg transition-shadow">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mx-auto mb-4">
            <Leaf className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-3xl font-bold text-green-600">120,000</h3>
          <p className="text-gray-600 text-sm mt-2">طن من الفراولة المصرية المصدرة</p>
          <span className="inline-block mt-2 px-3 py-1 rounded-full bg-orange-100 text-orange-600 text-xs font-medium">
            +14% عن 2023
          </span>
        </div>
      </div>

      {/* Export Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="eden-card p-6">
          <h3 className="eden-section-title">توزيع الصادرات المصرية 2024 (مليون دولار)</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={exportData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis type="number" stroke="#666" />
                <YAxis dataKey="name" type="category" width={120} stroke="#666" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #FF6B35',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                  {exportData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="eden-card p-6">
          <h3 className="eden-section-title">أهم الأسواق المستوردة من مصر</h3>
          <div className="space-y-4">
            {topExporters.map((item, index) => (
              <div key={index} className="flex items-center gap-4 p-4 bg-orange-50 rounded-xl">
                <span className="text-2xl">{item.flag}</span>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-800">{item.country}</span>
                    <span className="font-bold text-eden-orange">{item.value} مليون $</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-eden-orange to-eden-amber rounded-full"
                      style={{ width: `${(item.value / 262) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Strategic Context */}
      <div className="eden-card p-8">
        <h3 className="eden-section-title">الإطار الاستراتيجي لتموضع الصادرات المصرية</h3>
        <div className="prose max-w-none text-gray-700 leading-relaxed space-y-4">
          <p>
            يمثل هذا التقرير، الذي يعد الوثيقة التأسيسية الأولى في خطة التصدير الاستراتيجية، 
            تحليلاً عميقاً وشاملاً للبنية التحتية الفنية اللازمة لضمان نفاذ منتجات الشركة 
            إلى الأسواق ذات القيمة العالية (Tier-1 Markets) مثل الاتحاد الأوروبي والولايات المتحدة 
            ودول مجلس التعاون الخليجي.
          </p>
          <p>
            لا يقتصر التحدي في عام 2025 على جودة المنتج فحسب، بل يمتد ليشمل دقة التوصيف الجمركي 
            لتجنب الغرامات المالية، والقدرة على تتبع سلاسل التوريد رقمياً، والامتثال لمعايير 
            سلامة الغذاء التي تزداد صرامة يوماً بعد يوم.
          </p>
          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 p-6 rounded-xl border-r-4 border-eden-orange">
            <p className="font-semibold text-eden-dark mb-2">الرسالة الاستراتيجية:</p>
            <p className="text-gray-600">
              تشير البيانات المستخلصة من حركة التجارة الدولية إلى أن الشركات التي تنجح في 
              اختراق الأسواق العالمية هي تلك التي تتعامل مع "البيانات" و"المواصفات" 
              بنفس الأهمية التي تتعامل بها مع "المنتج" نفسه.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
