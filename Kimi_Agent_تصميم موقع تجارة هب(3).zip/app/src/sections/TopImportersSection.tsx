import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { Globe, TrendingUp, Building2, MapPin } from 'lucide-react';

// Top 10 Global Importers
const globalImporters = [
  { country: 'ألمانيا', value: 196.14, growth: 56.76, flag: '🇩🇪' },
  { country: 'الولايات المتحدة', value: 185.3, growth: 12.4, flag: '🇺🇸' },
  { country: 'فرنسا', value: 142.8, growth: 8.7, flag: '🇫🇷' },
  { country: 'المملكة المتحدة', value: 128.5, growth: 6.2, flag: '🇬🇧' },
  { country: 'اليابان', value: 115.2, growth: 4.8, flag: '🇯🇵' },
  { country: 'هولندا', value: 98.7, growth: 15.3, flag: '🇱🇺' },
  { country: 'إيطاليا', value: 87.4, growth: 7.1, flag: '🇮🇹' },
  { country: 'كندا', value: 76.3, growth: 9.5, flag: '🇨🇦' },
  { country: 'بلجيكا', value: 68.9, growth: 5.8, flag: '🇧🇪' },
  { country: 'إسبانيا', value: 62.1, growth: 11.2, flag: '🇪🇸' },
];

// Top 5 Arab Countries
const arabImporters = [
  { country: 'السعودية', value: 491, growth: 23, flag: '🇸🇦', details: 'أكبر مستورد للأغذية المصرية' },
  { country: 'الإمارات', value: 285, growth: 18, flag: '🇦🇪', details: 'مركز إعادة التصدير' },
  { country: 'الكويت', value: 142, growth: 15, flag: '🇰🇼', details: 'سوق واعد للخضروات المجمدة' },
  { country: 'قطر', value: 98, growth: 22, flag: '🇶🇦', details: 'نمو سريع في قطاع HORECA' },
  { country: 'عمان', value: 76, growth: 12, flag: '🇴🇲', details: 'سوق مستقر ومتنامي' },
];

// Top 3 African Countries
const africanImporters = [
  { country: 'كينيا', value: 45, growth: 28, flag: '🇰🇪', details: 'سوق شرق أفريقيا الرئيسي' },
  { country: 'موريشيوس', value: 32, growth: 19, flag: '🇲🇺', details: 'سوق سياحي راقٍ' },
  { country: 'جنوب أفريقيا', value: 28, growth: 14, flag: '🇿🇦', details: 'بوابة أفريقيا الجنوبية' },
];

const pieData = [
  { name: 'ألمانيا', value: 196.14, color: '#FF6B35' },
  { name: 'الولايات المتحدة', value: 185.3, color: '#F7931E' },
  { name: 'فرنسا', value: 142.8, color: '#FDB833' },
  { name: 'المملكة المتحدة', value: 128.5, color: '#FFC857' },
  { name: 'اليابان', value: 115.2, color: '#4CAF50' },
  { name: 'أخرى', value: 393, color: '#9E9E9E' },
];

export default function TopImportersSection() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">تحليل أكبر الدول المستوردة</h2>
        <p className="eden-section-subtitle">
          أكبر 10 دول مستوردة حول العالم، و5 دول عربية، و3 دول أفريقية
        </p>
      </div>

      {/* Global Top 10 */}
      <div className="eden-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-xl text-eden-dark">أكبر 10 دول مستوردة حول العالم</h3>
            <p className="text-sm text-gray-500">قيمة الواردات بالمليون دولار (2024)</p>
          </div>
        </div>
        
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={globalImporters} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" stroke="#666" />
              <YAxis dataKey="country" type="category" width={100} stroke="#666" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #FF6B35',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [`${value} مليون $`, 'الواردات']}
              />
              <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                {globalImporters.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={index < 3 ? '#FF6B35' : index < 6 ? '#F7931E' : '#FDB833'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {globalImporters.slice(0, 5).map((item, index) => (
            <div key={index} className="text-center p-4 bg-orange-50 rounded-xl">
              <span className="text-2xl">{item.flag}</span>
              <p className="font-semibold text-gray-800 mt-2">{item.country}</p>
              <p className="text-eden-orange font-bold">{item.value}M$</p>
              <span className="inline-block mt-1 px-2 py-0.5 rounded-full bg-green-100 text-green-600 text-xs">
                +{item.growth}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Pie Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="eden-card p-6">
          <h3 className="eden-section-title">توزيع الواردات العالمية</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #FF6B35',
                    borderRadius: '8px'
                  }}
                  formatter={(value: number) => [`${value} مليون $`, '']}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="eden-card p-6">
          <h3 className="eden-section-title">مؤشرات النمو في الأسواق الرئيسية</h3>
          <div className="space-y-4 mt-6">
            {globalImporters.slice(0, 6).map((item, index) => (
              <div key={index} className="flex items-center gap-4">
                <span className="text-xl">{item.flag}</span>
                <span className="flex-1 font-medium text-gray-700">{item.country}</span>
                <div className="flex items-center gap-3">
                  <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-eden-orange to-eden-amber rounded-full"
                      style={{ width: `${(item.growth / 60) * 100}%` }}
                    />
                  </div>
                  <span className="font-bold text-green-600 w-16 text-left">+{item.growth}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Arab Countries */}
      <div className="eden-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-xl text-eden-dark">أكبر 5 دول عربية مستوردة</h3>
            <p className="text-sm text-gray-500">قيمة واردات الأغذية المصرية بالمليون دولار (2024)</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {arabImporters.map((item, index) => (
            <div key={index} className="eden-card p-4 hover:shadow-eden-lg transition-shadow">
              <div className="text-center">
                <span className="text-3xl">{item.flag}</span>
                <h4 className="font-bold text-gray-800 mt-2">{item.country}</h4>
                <p className="text-2xl font-bold eden-text-gradient mt-1">{item.value}M$</p>
                <span className="inline-block mt-2 px-3 py-1 rounded-full bg-green-100 text-green-600 text-sm font-medium">
                  +{item.growth}% نمو
                </span>
                <p className="text-xs text-gray-500 mt-3">{item.details}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-green-100 rounded-xl">
          <h4 className="font-bold text-green-800 mb-2">الفرصة الاستراتيجية في السوق العربي:</h4>
          <p className="text-sm text-gray-700">
            السوق الخليجي يمر بمرحلة انتقالية هامة، حيث يتحول من سوق تقليدي يركز على السعر 
            إلى سوق منظم يركز على الجودة والسلامة الغذائية. نمو واردات السعودية من الأغذية 
            المصنعة المصرية بنسبة <strong>23%</strong> في 2024 يعكس هذه الفرصة.
          </p>
        </div>
      </div>

      {/* African Countries */}
      <div className="eden-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
            <MapPin className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-xl text-eden-dark">أكبر 3 دول أفريقية مستوردة</h3>
            <p className="text-sm text-gray-500">أسواق شرق وجنوب أفريقيا (2024)</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {africanImporters.map((item, index) => (
            <div key={index} className="eden-card p-6 hover:shadow-eden-lg transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <span className="text-4xl">{item.flag}</span>
                <div>
                  <h4 className="font-bold text-gray-800">{item.country}</h4>
                  <p className="text-sm text-gray-500">{item.details}</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-3xl font-bold eden-text-gradient">{item.value}M$</p>
                  <p className="text-xs text-gray-500">قيمة الواردات</p>
                </div>
                <div className="text-right">
                  <span className="inline-block px-3 py-1 rounded-full bg-green-100 text-green-600 text-sm font-medium">
                    +{item.growth}%
                  </span>
                  <p className="text-xs text-gray-500 mt-1">معدل النمو</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl">
          <h4 className="font-bold text-purple-800 mb-2">ميزة الكوميسا (COMESA):</h4>
          <p className="text-sm text-gray-700">
            توفر اتفاقية الكوميسا واتفاقية التجارة الحرة القارية الأفريقية (AfCFTA) 
            ميزة الدخول الصفري للجمارك للمنتجات المصرية في أسواق شرق أفريقيا، 
            مما يمنحها أفضلية سعرية أمام المنافسين من خارج القارة.
          </p>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="eden-card p-6 text-center">
          <TrendingUp className="w-8 h-8 text-eden-orange mx-auto mb-2" />
          <p className="text-2xl font-bold eden-text-gradient">1,461</p>
          <p className="text-sm text-gray-600">مليون دولار إجمالي واردات الخضروات المجمدة</p>
        </div>
        <div className="eden-card p-6 text-center">
          <Globe className="w-8 h-8 text-eden-amber mx-auto mb-2" />
          <p className="text-2xl font-bold eden-text-gradient">992</p>
          <p className="text-sm text-gray-600">مليون دولار واردات الدول العربية</p>
        </div>
        <div className="eden-card p-6 text-center">
          <MapPin className="w-8 h-8 text-eden-gold mx-auto mb-2" />
          <p className="text-2xl font-bold eden-text-gradient">105</p>
          <p className="text-sm text-gray-600">مليون دولار واردات أفريقيا</p>
        </div>
        <div className="eden-card p-6 text-center">
          <Building2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-green-600">18</p>
          <p className="text-sm text-gray-600">دولة مستهدفة في الخطة</p>
        </div>
      </div>
    </div>
  );
}
