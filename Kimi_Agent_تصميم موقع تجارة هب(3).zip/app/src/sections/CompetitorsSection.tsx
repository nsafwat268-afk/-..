import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { Building2, Globe, TrendingUp, AlertCircle } from 'lucide-react';

const globalCompetitors = [
  { name: 'جرينيارد (بلجيكا)', revenue: 5000, marketShare: 25, region: 'أوروبا' },
  { name: 'بوندويل (فرنسا)', revenue: 3200, marketShare: 18, region: 'أوروبا' },
  { name: 'نوماد فودز (هولندا)', revenue: 2800, marketShare: 15, region: 'أوروبا' },
  { name: 'McCain Foods (كندا)', revenue: 4200, marketShare: 22, region: 'أمريكا' },
  { name: 'Lamb Weston (أمريكا)', revenue: 3800, marketShare: 20, region: 'أمريكا' },
];

const localCompetitors = [
  { name: 'فارم فريتس مصر', product: 'بطاطس مقلية', strength: 'حجم ضخم', weakness: 'منافسة سعرية' },
  { name: 'جيفريكس', product: 'خرشوف وبامية', strength: 'سمعة تاريخية', weakness: 'حجم محدود' },
  { name: 'كولد أليكس', product: 'خضروات مجمدة', strength: 'شهادات متعددة', weakness: 'توسع محدود' },
  { name: 'مونتانا', product: 'ملوخية', strength: 'علامة تجارية', weakness: 'تخصص ضيق' },
];

const pricingComparison = [
  { product: 'فراولة مجمدة', egypt: 1.44, poland: 1.85, morocco: 2.05, spain: 1.65 },
  { product: 'بامية مجمدة', egypt: 2.38, turkey: 2.85, india: 2.15, china: 2.25 },
  { product: 'بطاطس مقلية', egypt: 1.85, belgium: 2.45, netherlands: 2.25, usa: 2.65 },
  { product: 'ملوخية مجمدة', egypt: 2.15, jordan: 2.85, lebanon: 3.15, none: 0 },
];

export default function CompetitorsSection() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">تحليل المنافسين وقدراتهم</h2>
        <p className="eden-section-subtitle">
          دراسة شاملة للمنافسين العالميين والمحليين في الأسواق المستهدفة
        </p>
      </div>

      {/* Global Competitors */}
      <div className="eden-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-xl text-eden-dark">المنافسون العالميون</h3>
            <p className="text-sm text-gray-500">العمالقة الذين يهيمنون على السوق العالمي</p>
          </div>
        </div>

        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={globalCompetitors} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" stroke="#666" />
              <YAxis dataKey="name" type="category" width={150} stroke="#666" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #FF6B35',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [`${value} مليون €`, 'الإيرادات']}
              />
              <Bar dataKey="revenue" radius={[0, 8, 8, 0]} fill="#FF6B35" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {globalCompetitors.map((comp, index) => (
            <div key={index} className="p-4 bg-orange-50 rounded-xl">
              <h4 className="font-semibold text-gray-800">{comp.name}</h4>
              <p className="text-sm text-gray-600 mt-1">{comp.region}</p>
              <div className="flex justify-between mt-3">
                <span className="text-eden-orange font-bold">{comp.revenue}M€</span>
                <span className="text-green-600 text-sm">{comp.marketShare}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Local Competitors */}
      <div className="eden-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-xl text-eden-dark">المنافسون المحليون في مصر</h3>
            <p className="text-sm text-gray-500">صراع العمالقة في السوق المصري</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {localCompetitors.map((comp, index) => (
            <div key={index} className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-xl">
              <h4 className="font-semibold text-gray-800">{comp.name}</h4>
              <p className="text-sm text-gray-600">المنتج الرئيسي: {comp.product}</p>
              <div className="flex gap-4 mt-3">
                <div className="flex-1">
                  <p className="text-xs text-green-600 font-medium">نقاط القوة</p>
                  <p className="text-sm text-gray-700">{comp.strength}</p>
                </div>
                <div className="flex-1">
                  <p className="text-xs text-red-600 font-medium">نقاط الضعف</p>
                  <p className="text-sm text-gray-700">{comp.weakness}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pricing Comparison */}
      <div className="eden-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-xl text-eden-dark">مقارنة الأسعار الدولية</h3>
            <p className="text-sm text-gray-500">أسعار التصدير FOB (دولار/كجم)</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="eden-table">
            <thead>
              <tr>
                <th>المنتج</th>
                <th>مصر</th>
                <th>المنافس 1</th>
                <th>المنافس 2</th>
                <th>المنافس 3</th>
              </tr>
            </thead>
            <tbody>
              {pricingComparison.map((item, index) => (
                <tr key={index}>
                  <td className="font-medium">{item.product}</td>
                  <td className="text-green-600 font-bold">${item.egypt}</td>
                  <td>${Object.values(item)[2]}</td>
                  <td>${Object.values(item)[3]}</td>
                  <td>${Object.values(item)[4]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Strategy Recommendation */}
      <div className="bg-gradient-to-r from-eden-orange to-eden-amber p-6 rounded-2xl text-white">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-xl mb-2">استراتيجية التمايز التنافسي</h3>
            <p className="text-white/90 leading-relaxed">
              بناءً على تحليل المنافسين، يجب أن تتبنى إيدن جاردن استراتيجية 
              <strong>"الشريك المرن وعالي الجودة"</strong> (Agile Quality Partner):
            </p>
            <ul className="mt-4 space-y-2 text-white/90">
              <li>• تجنب المنافسة السعرية المباشرة مع فارم فريتس في البطاطس</li>
              <li>• استهداف قطاع التصنيع (B2B) للمصانع الأوروبية</li>
              <li>• التركيز على العلامات الخاصة (Private Label)</li>
              <li>• التخصص في النيش ماركت: بامية زيرو، فراولة درجة أولى</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
