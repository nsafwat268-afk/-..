import { useState } from 'react';
import { TrendingUp, Calculator, Info } from 'lucide-react';

const pricingData = {
  saudi: {
    name: 'المملكة العربية السعودية',
    flag: '🇸🇦',
    currency: 'ريال سعودي',
    products: [
      { name: 'فراولة مجمدة', retail: '18-25', wholesale: '12-16', industrial: '10-14', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '22-30', wholesale: '16-22', industrial: '14-18', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '15-22', wholesale: '10-15', industrial: '8-12', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '12-18', wholesale: '8-12', industrial: '6-10', fob: '0.95-1.45' },
    ],
    notes: 'السوق السعودي يتميز بقدرة شرائية عالية وطلب على المنتجات المصرية',
  },
  uae: {
    name: 'الإمارات العربية المتحدة',
    flag: '🇦🇪',
    currency: 'درهم إماراتي',
    products: [
      { name: 'فراولة مجمدة', retail: '18-26', wholesale: '12-17', industrial: '10-15', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '22-32', wholesale: '16-24', industrial: '14-20', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '16-24', wholesale: '11-16', industrial: '9-13', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '14-20', wholesale: '9-13', industrial: '7-11', fob: '0.95-1.45' },
    ],
    notes: 'الإمارات بوابة لإعادة التصدير لدول الخليج',
  },
  kuwait: {
    name: 'الكويت',
    flag: '🇰🇼',
    currency: 'دينار كويتي',
    products: [
      { name: 'فراولة مجمدة', retail: '1.5-2.2', wholesale: '1.0-1.5', industrial: '0.8-1.2', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '1.8-2.6', wholesale: '1.3-1.9', industrial: '1.1-1.6', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '1.3-1.9', wholesale: '0.9-1.3', industrial: '0.7-1.1', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '1.0-1.5', wholesale: '0.7-1.0', industrial: '0.5-0.8', fob: '0.95-1.45' },
    ],
    notes: 'سوق واعد مع قدرة شرائية مرتفعة',
  },
  germany: {
    name: 'ألمانيا',
    flag: '🇩🇪',
    currency: 'يورو',
    products: [
      { name: 'فراولة مجمدة', retail: '3.5-4.5', wholesale: '2.38-3.68', industrial: '1.6-2.2', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '4.0-5.5', wholesale: '2.8-4.0', industrial: '2.2-3.2', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '2.8-3.8', wholesale: '1.9-2.8', industrial: '1.5-2.2', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '3.0-4.0', wholesale: '2.0-2.8', industrial: '1.6-2.2', fob: '0.95-1.45' },
    ],
    notes: 'سوق كبير مع متطلبات جودة صارمة',
  },
  usa: {
    name: 'الولايات المتحدة',
    flag: '🇺🇸',
    currency: 'دولار أمريكي',
    products: [
      { name: 'فراولة مجمدة', retail: '3.5-5.0', wholesale: '2.0-3.0', industrial: '1.5-2.0', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '4.0-5.5', wholesale: '2.8-4.0', industrial: '2.2-3.0', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '2.5-3.5', wholesale: '1.7-2.5', industrial: '1.3-1.9', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '3.5-4.5', wholesale: '2.4-3.2', industrial: '1.9-2.6', fob: '0.95-1.45' },
    ],
    notes: 'سوق ضخم مع طلب على المنتجات العضوية',
  },
  uk: {
    name: 'المملكة المتحدة',
    flag: '🇬🇧',
    currency: 'جنيه إسترليني',
    products: [
      { name: 'فراولة مجمدة', retail: '3.0-4.5', wholesale: '2.0-3.0', industrial: '1.5-2.0', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '3.5-5.0', wholesale: '2.4-3.5', industrial: '1.9-2.8', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '2.5-3.5', wholesale: '1.7-2.5', industrial: '1.3-1.9', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '3.0-4.0', wholesale: '2.0-2.8', industrial: '1.6-2.2', fob: '0.95-1.45' },
    ],
    notes: 'اتفاقية شراكة مع مصر بعد البريكست',
  },
  kenya: {
    name: 'كينيا',
    flag: '🇰🇪',
    currency: 'شيلنج كيني',
    products: [
      { name: 'فراولة مجمدة', retail: '250-350', wholesale: '180-250', industrial: '150-200', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '300-420', wholesale: '220-300', industrial: '180-240', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '200-280', wholesale: '150-200', industrial: '120-160', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '180-250', wholesale: '130-180', industrial: '100-140', fob: '0.95-1.45' },
    ],
    notes: 'سوق شرق أفريقيا الرئيسي مع ميزة الكوميسا',
  },
  mauritius: {
    name: 'موريشيوس',
    flag: '🇲🇺',
    currency: 'روبية موريشيوسية',
    products: [
      { name: 'فراولة مجمدة', retail: '100-150', wholesale: '70-100', industrial: '50-80', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '120-170', wholesale: '85-120', industrial: '65-95', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '80-120', wholesale: '55-80', industrial: '45-65', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '90-130', wholesale: '65-90', industrial: '50-75', fob: '0.95-1.45' },
    ],
    notes: 'سوق سياحي راقٍ مع قدرة شرائية عالية',
  },
  southafrica: {
    name: 'جنوب أفريقيا',
    flag: '🇿🇦',
    currency: 'راند جنوب أفريقي',
    products: [
      { name: 'فراولة مجمدة', retail: '30-45', wholesale: '22-30', industrial: '18-25', fob: '1.08-1.58' },
      { name: 'بامية مجمدة', retail: '35-50', wholesale: '25-35', industrial: '20-28', fob: '1.70-3.07' },
      { name: 'بطاطس مقلية', retail: '25-35', wholesale: '18-25', industrial: '14-20', fob: '1.20-1.85' },
      { name: 'ملوخية مجمدة', retail: '28-38', wholesale: '20-28', industrial: '16-22', fob: '0.95-1.45' },
    ],
    notes: 'بوابة أفريقيا الجنوبية مع بنية تحتية متطورة',
  },
};

export default function PricingSection() {
  const [selectedCountry, setSelectedCountry] = useState<keyof typeof pricingData>('saudi');
  const countryData = pricingData[selectedCountry];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">استراتيجية التسعير في كل بلد</h2>
        <p className="eden-section-subtitle">
          تحليل الأسعار والهوامش الربحية في الأسواق المستهدفة
        </p>
      </div>

      {/* Country Selector */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {Object.entries(pricingData).map(([key, data]) => (
          <button
            key={key}
            onClick={() => setSelectedCountry(key as keyof typeof pricingData)}
            className={`p-3 rounded-xl text-sm font-medium transition-all ${
              selectedCountry === key
                ? 'bg-gradient-to-r from-eden-orange to-eden-amber text-white shadow-eden'
                : 'bg-white text-gray-600 hover:bg-orange-50 border border-orange-100'
            }`}
          >
            <span className="text-lg">{data.flag}</span>
            <span className="block mt-1">{data.name}</span>
          </button>
        ))}
      </div>

      {/* Selected Country Info */}
      <div className="eden-card p-6">
        <div className="flex items-center gap-4 mb-6">
          <span className="text-4xl">{countryData.flag}</span>
          <div>
            <h3 className="text-2xl font-bold text-eden-dark">{countryData.name}</h3>
            <p className="text-gray-500">العملة: {countryData.currency}</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="eden-table w-full">
            <thead>
              <tr>
                <th>المنتج</th>
                <th>سعر FOB (دولار/كجم)</th>
                <th>سعر التصنيع</th>
                <th>سعر الجملة</th>
                <th>سعر التجزئة</th>
              </tr>
            </thead>
            <tbody>
              {countryData.products.map((product, index) => (
                <tr key={index}>
                  <td className="font-medium">{product.name}</td>
                  <td className="text-green-600 font-bold">${product.fob}</td>
                  <td>{product.industrial}</td>
                  <td>{product.wholesale}</td>
                  <td className="text-eden-orange font-bold">{product.retail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 p-4 bg-orange-50 rounded-xl">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-eden-orange flex-shrink-0 mt-0.5" />
            <p className="text-gray-700">{countryData.notes}</p>
          </div>
        </div>
      </div>

      {/* Margin Calculator */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          حاسبة الهامش الربحي
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
          <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
            <p className="text-sm text-gray-600 mb-2">السوق الأوروبي</p>
            <p className="text-3xl font-bold text-green-600">25-40%</p>
            <p className="text-xs text-gray-500 mt-1">هامش ربح متوقع</p>
          </div>
          <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
            <p className="text-sm text-gray-600 mb-2">السوق الخليجي</p>
            <p className="text-3xl font-bold text-blue-600">20-35%</p>
            <p className="text-xs text-gray-500 mt-1">هامش ربح متوقع</p>
          </div>
          <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
            <p className="text-sm text-gray-600 mb-2">السوق الأفريقي</p>
            <p className="text-3xl font-bold text-purple-600">15-25%</p>
            <p className="text-xs text-gray-500 mt-1">هامش ربح متوقع</p>
          </div>
        </div>
      </div>

      {/* Pricing Strategy */}
      <div className="bg-gradient-to-r from-eden-orange to-eden-amber p-6 rounded-2xl text-white">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-xl mb-2">استراتيجية التسعير الموصى بها</h3>
            <ul className="space-y-2 text-white/90">
              <li>• استهداف الهامش الأعلى في الأسواق الأوروبية (25-40%)</li>
              <li>• التوازن بين الحجم والهامش في الخليج (20-35%)</li>
              <li>• التركيز على الحجم في أفريقيا مع هامش 15-25%</li>
              <li>• مراجعة الأسعار شهرياً بناءً على تكاليف الشحن</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
