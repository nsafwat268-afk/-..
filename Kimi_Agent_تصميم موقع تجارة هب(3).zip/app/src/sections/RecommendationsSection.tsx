import { Lightbulb, Target, CheckCircle, TrendingUp, Calendar } from 'lucide-react';

const immediateActions = [
  {
    title: 'التصحيح الفوري للأكواد',
    description: 'اعتماد الكود 2004.10 لجميع منتجات البطاطس نصف المقلية',
    priority: 'عالي',
  },
  {
    title: 'الاستثمار في الجودة',
    description: 'ترقية أنظمة الفرز البصري (Optical Sorting) في المصنع',
    priority: 'عالي',
  },
  {
    title: 'تأمين الشهادات',
    description: 'الحصول على شهادة GlobalGAP للمزارع وBRCGS للمصنع',
    priority: 'عالي',
  },
  {
    title: 'الذكاء السوقي',
    description: 'تفعيل وحدة تحليل بيانات داخلية تستخدم Trade Map وPython',
    priority: 'متوسط',
  },
];

const roadmap = [
  {
    phase: 'المرحلة الأولى: الاختراق والتمكين',
    period: 'السنة 1',
    items: [
      'جعل الفراولة المجمدة رأس الحربة للدخول إلى الأسواق الأوروبية',
      'الحصول على شهادات BRCGS وIFS للمصنع',
      'البدء بتصدير الخضروات المجمدة للسوق السعودي',
      'بناء علاقات مع 3-5 مستوردين رئيسيين',
    ],
  },
  {
    phase: 'المرحلة الثانية: التوسع والتنويع',
    period: 'السنة 2-3',
    items: [
      'استهداف السوق الروسي بكميات أكبر',
      'طرح منتجات جديدة: الخرشوف المجهز',
      'بناء علامة تجارية خاصة بإيدن جاردن',
      'التوسع في أسواق أفريقيا',
    ],
  },
  {
    phase: 'المرحلة الثالثة: التكامل والريادة',
    period: 'السنة 4-5',
    items: [
      'الاستثمار في زراعة تعاقدية لتأمين 50% من الاحتياجات',
      'تطوير خطوط إنتاج للخضروات المشوية',
      'الريادة في سوق المنتجات المصرية المجمدة',
      'التوسع في أسواق جديدة (آسيا)',
    ],
  },
];

const keySuccessFactors = [
  {
    title: 'الجودة المستمرة',
    description: 'تقديم جودة ثابتة في كل شحنة',
    icon: CheckCircle,
  },
  {
    title: 'الامتثال التنظيمي',
    description: 'الالتزام بجميع المعايير الدولية',
    icon: CheckCircle,
  },
  {
    title: 'المرونة',
    description: 'القدرة على التكيف مع متغيرات السوق',
    icon: TrendingUp,
  },
  {
    title: 'البيانات',
    description: 'اتخاذ القرارات بناءً على تحليل البيانات',
    icon: Lightbulb,
  },
];

export default function RecommendationsSection() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">الخاتمة والتوصيات الفنية</h2>
        <p className="eden-section-subtitle">
          خارطة طريق التنفيذ وخطوات عملية لـ Eden Garden
        </p>
      </div>

      {/* Executive Summary */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-eden-dark via-eden-dark to-eden-orange p-8">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-eden-orange rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2" />
        </div>
        <div className="relative z-10">
          <h3 className="text-2xl font-bold text-white mb-4">الخلاصة التنفيذية</h3>
          <p className="text-white/90 leading-relaxed">
            تمتلك إيدن جاردن فرصة حقيقية للتحول من شركة تصدير ناشئة إلى لاعب إقليمي مؤثر، 
            شريطة أن تبني قراراتها على البيانات، وتلتزم بأعلى معايير الجودة، 
            وتتمتع بالمرونة الكافية للتكيف مع متغيرات السوق العالمية المتسارعة. 
            السوق العالمي متعطش للمنتج المصري، والنجاح مرهون بالقدرة على تقديم 
            "الجودة المستمرة" (Consistent Quality) بالسعر التنافسي.
          </p>
        </div>
      </div>

      {/* Immediate Actions */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title flex items-center gap-2">
          <Target className="w-5 h-5" />
          الإجراءات الفورية
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {immediateActions.map((action, index) => (
            <div key={index} className="p-4 bg-orange-50 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-gray-800">{action.title}</h4>
                <span className={`px-2 py-0.5 rounded-full text-xs ${
                  action.priority === 'عالي' 
                    ? 'bg-red-100 text-red-600' 
                    : 'bg-yellow-100 text-yellow-600'
                }`}>
                  أولوية {action.priority}
                </span>
              </div>
              <p className="text-sm text-gray-600">{action.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Roadmap */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          خارطة طريق التنفيذ
        </h3>
        <div className="space-y-6 mt-4">
          {roadmap.map((phase, index) => (
            <div key={index} className="relative">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center text-white font-bold flex-shrink-0">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-bold text-lg text-eden-dark">{phase.phase}</h4>
                    <span className="px-3 py-1 rounded-full bg-orange-100 text-eden-orange text-sm">
                      {phase.period}
                    </span>
                  </div>
                  <ul className="space-y-2">
                    {phase.items.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-gray-700">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Key Success Factors */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {keySuccessFactors.map((factor, index) => {
          const Icon = factor.icon;
          return (
            <div key={index} className="eden-card p-6 text-center hover:shadow-eden-lg transition-shadow">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center mx-auto mb-4">
                <Icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="font-bold text-gray-800">{factor.title}</h3>
              <p className="text-sm text-gray-600 mt-2">{factor.description}</p>
            </div>
          );
        })}
      </div>

      {/* Final Message */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 p-8 rounded-2xl text-white">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <Lightbulb className="w-8 h-8" />
          </div>
          <div>
            <h3 className="font-bold text-2xl mb-4">الرسالة الختامية</h3>
            <p className="text-white/90 leading-relaxed text-lg">
              تمتلك إيدن جاردن فرصة ذهبية في 2025 للاستفادة من الطلب العالمي المتزايد 
              على الغذاء المصري. النجاح لن يعتمد فقط على جودة المنتج، بل على كفاءة 
              "إدارة سلسلة الإمداد" والقدرة على "المناورة التنظيمية" في أسواق معقدة 
              مثل السعودية وأوروبا. التركيز على القيمة المضافة والامتثال هو المفتاح 
              لتحويل الفرص الموسمية إلى نمو مستدام.
            </p>
          </div>
        </div>
      </div>

      {/* Contact */}
      <div className="eden-card p-6 text-center">
        <p className="text-gray-600">
          للاستفسارات والدعم الاستشاري، يرجى التواصل مع
        </p>
        <p className="text-xl font-bold eden-text-gradient mt-2">
          أ.د/ محمد العاصي - استشاري التجارة الدولية
        </p>
        <p className="text-gray-500 mt-1">
          وحدة الاستشارات - تجارة هب
        </p>
      </div>
    </div>
  );
}
