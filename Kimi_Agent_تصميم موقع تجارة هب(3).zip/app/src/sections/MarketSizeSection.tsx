import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  Legend
} from 'recharts';
import { TrendingUp, DollarSign, Package, Globe } from 'lucide-react';

const marketGrowthData = [
  { year: '2020', value: 18.5, growth: 0 },
  { year: '2021', value: 19.2, growth: 3.8 },
  { year: '2022', value: 20.1, growth: 4.7 },
  { year: '2023', value: 21.35, growth: 6.2 },
  { year: '2024', value: 22.8, growth: 6.8 },
  { year: '2025', value: 24.5, growth: 7.5 },
  { year: '2026', value: 26.3, growth: 7.3 },
  { year: '2027', value: 28.2, growth: 7.2 },
  { year: '2028', value: 30.1, growth: 6.7 },
  { year: '2029', value: 32.0, growth: 6.3 },
  { year: '2030', value: 34.2, growth: 6.9 },
  { year: '2031', value: 36.5, growth: 6.7 },
  { year: '2032', value: 38.9, growth: 6.6 },
];

const frozenVegetablesData = [
  { year: '2020', value: 19.8 },
  { year: '2021', value: 20.5 },
  { year: '2022', value: 21.35 },
  { year: '2023', value: 22.1 },
  { year: '2024', value: 23.2 },
  { year: '2025', value: 24.8 },
  { year: '2026', value: 26.5 },
  { year: '2027', value: 28.3 },
  { year: '2028', value: 30.2 },
  { year: '2029', value: 32.1 },
  { year: '2030', value: 34.0 },
  { year: '2031', value: 36.2 },
  { year: '2032', value: 38.5 },
];

const cagrData = [
  { segment: 'الخضروات المجمدة', cagr: 5.08, color: '#FF6B35' },
  { segment: 'البطاطس المقلية', cagr: 4.85, color: '#F7931E' },
  { segment: 'الفراولة المجمدة', cagr: 6.2, color: '#FDB833' },
  { segment: 'الخضروات الورقية', cagr: 4.5, color: '#FFC857' },
];

export default function MarketSizeSection() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">حجم السوق العالمي والنمو المتوقع</h2>
        <p className="eden-section-subtitle">
          تحليل ديناميكيات الطلب العالمي على الأغذية المجمدة (2020-2032)
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="eden-card p-6 text-center">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center mx-auto mb-4">
            <DollarSign className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-2xl font-bold eden-text-gradient">21.35 مليار</h3>
          <p className="text-gray-600 text-sm mt-2">حجم سوق الخضروات المجمدة 2024</p>
        </div>

        <div className="eden-card p-6 text-center">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-amber to-eden-gold flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-2xl font-bold eden-text-gradient">38.9 مليار</h3>
          <p className="text-gray-600 text-sm mt-2">الحجم المتوقع 2032</p>
        </div>

        <div className="eden-card p-6 text-center">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-gold to-eden-yellow flex items-center justify-center mx-auto mb-4">
            <Package className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-2xl font-bold eden-text-gradient">5.08%</h3>
          <p className="text-gray-600 text-sm mt-2">معدل النمو السنوي المركب CAGR</p>
        </div>

        <div className="eden-card p-6 text-center">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mx-auto mb-4">
            <Globe className="w-7 h-7 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-green-600">82%</h3>
          <p className="text-gray-600 text-sm mt-2">نسبة النمو المتوقع 2024-2032</p>
        </div>
      </div>

      {/* Market Growth Chart */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title">حجم سوق الأغذية المجمدة العالمي (2020-2032)</h3>
        <p className="text-gray-600 text-sm mb-6">
          القيمة بالمليار دولار أمريكي | Frozen Food Market Size (Billion USD)
        </p>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={marketGrowthData}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FF6B35" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#FF6B35" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="year" stroke="#666" />
              <YAxis stroke="#666" domain={[15, 42]} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #FF6B35',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [`${value} مليار $`, 'حجم السوق']}
              />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="value" 
                stroke="#FF6B35" 
                fillOpacity={1} 
                fill="url(#colorValue)" 
                strokeWidth={3}
                name="حجم السوق (مليار $)"
              />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="#F7931E" 
                strokeWidth={2}
                dot={{ fill: '#FF6B35', strokeWidth: 2, r: 4 }}
                name="الاتجاه"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 p-4 bg-orange-50 rounded-xl">
          <p className="text-sm text-gray-700">
            <strong>المصدر:</strong> تحليل بيانات Grand View Research, Mordor Intelligence, 
            وإحصائيات التجارة العالمية 2024
          </p>
        </div>
      </div>

      {/* Frozen Vegetables Specific */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title">سوق الخضروات المجمدة بالتفصيل (2020-2032)</h3>
        <p className="text-gray-600 text-sm mb-6">
          Frozen Vegetables Market Growth Trajectory
        </p>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={frozenVegetablesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="year" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #F7931E',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [`${value} مليار $`, 'حجم السوق']}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="#F7931E" 
                strokeWidth={3}
                dot={{ fill: '#F7931E', strokeWidth: 2, r: 5 }}
                name="حجم السوق (مليار $)"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* CAGR Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="eden-card p-6">
          <h3 className="eden-section-title">معدل النمو السنوي المركب (CAGR) حسب القطاع</h3>
          <div className="space-y-4 mt-6">
            {cagrData.map((item, index) => (
              <div key={index} className="flex items-center gap-4">
                <div 
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="flex-1 font-medium text-gray-700">{item.segment}</span>
                <div className="flex items-center gap-3">
                  <div className="w-32 h-3 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{ 
                        width: `${(item.cagr / 7) * 100}%`,
                        backgroundColor: item.color
                      }}
                    />
                  </div>
                  <span className="font-bold text-eden-orange w-16">{item.cagr}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="eden-card p-6">
          <h3 className="eden-section-title">عوامل النgrowth الرئيسية</h3>
          <div className="space-y-4 mt-6">
            <div className="flex items-start gap-3 p-4 bg-orange-50 rounded-xl">
              <div className="w-8 h-8 rounded-lg bg-eden-orange flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">1</span>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800">تغير نمط الحياة</h4>
                <p className="text-sm text-gray-600">
                  63% من المستهلكين ينظرون للأغذية المجمدة كبديل مساوٍ للطازجة
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3 p-4 bg-orange-50 rounded-xl">
              <div className="w-8 h-8 rounded-lg bg-eden-amber flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">2</span>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800">الأمن الغذائي</h4>
                <p className="text-sm text-gray-600">
                  تقليل هدر الطعام وتثبيت ميزانية الإنفاق الغذائي
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3 p-4 bg-orange-50 rounded-xl">
              <div className="w-8 h-8 rounded-lg bg-eden-gold flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">3</span>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800">قطاع الخدمات الغذائية</h4>
                <p className="text-sm text-gray-600">
                  HORECA يستحوذ على أكثر من 70% من الطلب في الأسواق المتقدمة
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Market Drivers */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title">ديناميكيات الطلب العالمي على الأغذية المجمدة</h3>
        <div className="prose max-w-none text-gray-700 leading-relaxed mt-4">
          <p>
            يشهد العالم تحولاً متسارعاً نحو استهلاك الخضروات والفواكه المجمدة، مدفوعاً بمجموعة من العوامل 
            الاقتصادية والاجتماعية التي تعززت في أعقاب الجائحة وموجات التضخم العالمية. لم تعد الأغذية المجمدة 
            تُعتبر مجرد "خيار طوارئ" أو بديل رخيص، بل أصبحت ركيزة أساسية في الأمن الغذائي الأسري والمؤسسي.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
              <h4 className="font-bold text-blue-800 mb-2">السوق الأوروبي</h4>
              <p className="text-sm text-gray-700">
                يمثل 35% من السوق العالمي، مع نمو متوسط 4.8% سنوياً. 
                ألمانيا وألمانيا والمملكة المتحدة هي أكبر الأسواق.
              </p>
            </div>
            <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
              <h4 className="font-bold text-green-800 mb-2">السوق الأمريكي</h4>
              <p className="text-sm text-gray-700">
                نمو سريع بنسبة 6.2% سنوياً، مع زيادة الطلب على المنتجات العضوية 
                والمنتجات الموجهة لصناعة العصائر.
              </p>
            </div>
            <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
              <h4 className="font-bold text-purple-800 mb-2">السوق الآسيوي</h4>
              <p className="text-sm text-gray-700">
                أسرع الأسواق نمواً بنسبة 7.5% سنوياً، مع زيادة الطلب في الصين والهند 
                واليابان.
              </p>
            </div>
            <div className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl">
              <h4 className="font-bold text-orange-800 mb-2">الشرق الأوسط وأفريقيا</h4>
              <p className="text-sm text-gray-700">
                نمو مستقر بنسبة 5.5% سنوياً، مع زيادة الاستثمارات في البنية التحتية 
                للتبريد.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
