import { FileCheck, AlertTriangle, CheckCircle, Info, Building2, Leaf, Ship } from 'lucide-react';

const exportDocuments = [
  {
    category: 'الوثائق الأساسية',
    icon: FileCheck,
    docs: [
      { name: 'فاتورة تجارية (Commercial Invoice)', required: true, notes: 'موقعة ومختومة من المصدر' },
      { name: 'قائمة التعبئة (Packing List)', required: true, notes: 'تفاصيل المحتويات والأوزان' },
      { name: 'شهادة المنشأ (Certificate of Origin)', required: true, notes: 'من الغرفة التجارية أو GOEIC' },
      { name: 'بوليصة الشحن (Bill of Lading)', required: true, notes: 'من شركة الشحن' },
    ]
  },
  {
    category: 'الوثائق الصحية والجودة',
    icon: Leaf,
    docs: [
      { name: 'شهادة الصحة النباتية (Phytosanitary Certificate)', required: true, notes: 'من الحجر الزراعي المصري' },
      { name: 'شهادة تحليل المبيدات (Pesticide Residue Analysis)', required: true, notes: 'معتمد من ISO 17025' },
      { name: 'شهادة GlobalGAP', required: false, notes: 'للمزارع الموردة' },
      { name: 'شهادة BRCGS / FSSC 22000', required: false, notes: 'للمصنع' },
    ]
  },
  {
    category: 'التسجيلات والتراخيص',
    icon: Building2,
    docs: [
      { name: 'تسجيل GOEIC', required: true, notes: 'الهيئة العامة للرقابة على الصادرات' },
      { name: 'تسجيل المزارع (Farm Registration)', required: true, notes: 'للحجر الزراعي' },
      { name: 'ترخيص التصدير', required: true, notes: 'من الجهاز المركزي للتعبئة' },
      { name: 'تسجيل المنتجات في بلد الوجهة', required: true, notes: 'حسب متطلبات كل دولة' },
    ]
  },
  {
    category: 'وثائق الشحن',
    icon: Ship,
    docs: [
      { name: 'تأمين الشحنة (Cargo Insurance)', required: true, notes: 'تغطية كاملة للشحنة' },
      { name: 'شهادة التبريد (Cold Chain Certificate)', required: true, notes: 'تتبع درجة الحرارة' },
      { name: 'إقرار جمركي مصدر (Customs Export Declaration)', required: true, notes: 'من الجمارك المصرية' },
      { name: 'شهادة الوزن (Weight Certificate)', required: false, notes: 'حسب طلب المستورد' },
    ]
  }
];

const labelingRequirements = [
  'اسم المنتج باللغتين العربية والإنجليزية',
  'بلد المنشأ (Product of Egypt)',
  'تاريخ الإنتاج وتاريخ الانتهاء',
  'المكونات والمواد المضافة',
  'مسببات الحساسية (Allergens)',
  'المعلومات الغذائية (Nutrition Facts)',
  'تعليمات التخزين (-18°C)',
  'رقم التتبع (Traceability Code)',
  'الوزن الصافي',
  'اسم المصدر وبيانات الاتصال',
];

export default function DocumentsSection() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">الورقيات المطلوبة لخروج المنتج من مصر</h2>
        <p className="eden-section-subtitle">
          قائمة شاملة بالوثائق والشهادات المطلوبة للتصدير من مصر
        </p>
      </div>

      {/* Warning */}
      <div className="bg-red-50 border-r-4 border-red-500 p-6 rounded-xl">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h3 className="font-bold text-red-700 text-lg mb-2">تنبيه هام</h3>
            <p className="text-gray-700 leading-relaxed">
              لا مجال للخطأ في ملف الوثائق؛ فخطأ واحد قد يؤدي إلى حظر الشركة من التصدير 
              لدولة كاملة. يجب مراجعة جميع الوثائق قبل الشحن بـ 48 ساعة على الأقل.
            </p>
          </div>
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {exportDocuments.map((category, index) => {
          const Icon = category.icon;
          return (
            <div key={index} className="eden-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center">
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-bold text-lg text-eden-dark">{category.category}</h3>
              </div>
              <div className="space-y-3">
                {category.docs.map((doc, i) => (
                  <div key={i} className={`p-3 rounded-lg ${doc.required ? 'bg-orange-50' : 'bg-gray-50'}`}>
                    <div className="flex items-start gap-2">
                      {doc.required ? (
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                      ) : (
                        <Info className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                      )}
                      <div>
                        <p className={`font-medium ${doc.required ? 'text-gray-800' : 'text-gray-600'}`}>
                          {doc.name}
                        </p>
                        <p className="text-xs text-gray-500">{doc.notes}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Labeling Requirements */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title">متطلبات الملصقات (Labeling Requirements)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {labelingRequirements.map((req, index) => (
            <div key={index} className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
              <CheckCircle className="w-4 h-4 text-eden-orange" />
              <span className="text-gray-700">{req}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Process Timeline */}
      <div className="eden-card p-6">
        <h3 className="eden-section-title">خطوات استخراج الوثائق</h3>
        <div className="relative">
          <div className="absolute right-4 top-0 bottom-0 w-0.5 bg-gradient-to-b from-eden-orange to-eden-gold" />
          <div className="space-y-6">
            {[
              { step: 1, title: 'تسجيل الشركة في GOEIC', time: '2-4 أسابيع', desc: 'تقديم المستندات المطلوبة للهيئة العامة للرقابة على الصادرات' },
              { step: 2, title: 'تسجيل المزارع في الحجر الزراعي', time: '1-2 أسبوع', desc: 'تسجيل المزارع الموردة في قاعدة بيانات الحجر الزراعي' },
              { step: 3, title: 'الحصول على شهادات الجودة', time: '4-8 أسابيع', desc: 'GlobalGAP للمزارع، BRCGS للمصنع' },
              { step: 4, title: 'فحص المبيدات', time: '3-5 أيام', desc: 'إرسال عينات للمعامل المعتمدة (ISO 17025)' },
              { step: 5, title: 'إصدار الوثائق', time: '2-3 أيام', desc: 'جمع جميع الوثائق ومراجعتها قبل الشحن' },
            ].map((item, index) => (
              <div key={index} className="flex items-start gap-4 relative">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center text-white font-bold text-sm z-10">
                  {item.step}
                </div>
                <div className="flex-1 bg-orange-50 p-4 rounded-xl">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-gray-800">{item.title}</h4>
                    <span className="text-xs text-eden-orange font-medium">{item.time}</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
