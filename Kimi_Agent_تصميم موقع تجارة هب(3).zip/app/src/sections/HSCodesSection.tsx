import { AlertTriangle, CheckCircle, Info, FileCode } from 'lucide-react';

const hsCodesData = [
  {
    product: 'بطاطس نصف مقلية (Frozen Par-fried Potatoes)',
    globalCode: '2004.10',
    usCode: '2004.10.80.40',
    gccCode: '2004.10.00.00.00 (12-digit)',
    notes: 'تأكد من ذكر نوع الزيت المستخدم في القلي',
    warning: true,
    warningText: 'لا يتم تصنيفها تحت 0710.10 - يجب استخدام 2004.10',
  },
  {
    product: 'فراولة مجمدة (IQF Strawberries)',
    globalCode: '0811.10',
    usCode: '0811.10.00.70',
    gccCode: '0811.10.00.00.00',
    notes: 'حدد نسبة السكر بدقة - إذا كانت ≤25% استخدم 0811.10.00.50',
    warning: false,
    warningText: '',
  },
  {
    product: 'ملوخية مجمدة (Frozen Molokhia)',
    globalCode: '0710.80',
    usCode: '0710.80.97.50',
    gccCode: '0710.80.00.00.00',
    notes: 'الاسم العلمي Corchorus olitorius إلزامي في الوثائق',
    warning: false,
    warningText: '',
  },
  {
    product: 'بامية مجمدة (Frozen Okra)',
    globalCode: '0710.80',
    usCode: '0710.80.93.00',
    gccCode: '0710.80.00.00.xx',
    notes: 'يجب أن تكون غير تليفية - حصاد مبكر',
    warning: false,
    warningText: '',
  },
  {
    product: 'قرنبيط مجمد (Frozen Cauliflower)',
    globalCode: '0710.80',
    usCode: '0710.80.97.30',
    gccCode: '0710.80.00.00.xx',
    notes: 'مصنف كـ "مقطع" (Florets) إذا كان مقطعاً',
    warning: false,
    warningText: '',
  },
  {
    product: 'خضار مشكل مجمد (Mixed Vegetables)',
    globalCode: '0710.90',
    usCode: '0710.90.91.00',
    gccCode: '0710.90.00.00.00',
    notes: 'نسب المكونات مطلوبة - لا يجب سيادة عنصر واحد',
    warning: true,
    warningText: 'قد تعيد الجمارك التصنيف بناءً على المكون الأغلب',
  },
];

const classificationPhilosophy = [
  {
    title: 'الفصل 07 - الخضروات',
    description: 'يغطي الخضروات الطازجة أو المبردة أو المجمدة النيئة',
    examples: ['الملوخية المجمدة', 'البامية المجمدة', 'القرنبيط المجمد'],
    condition: 'يجب أن تكون الخضروات غير محضرة (بدون قلي أو طهي)',
  },
  {
    title: 'الفصل 08 - الفواكه',
    description: 'يغطي الفواكه الطازجة أو المجمدة',
    examples: ['الفراولة المجمدة', 'التوت المجمد'],
    condition: 'قد تحتوي على سكر حتى 25%',
  },
  {
    title: 'الفصل 20 - محضرات الخضر',
    description: 'يغطي المنتجات المحضرة أو المصنعة',
    examples: ['البطاطس نصف المقلية', 'الخضروات المطبوخة'],
    condition: 'أي عملية قلي أو طهي تنتقل إلى هذا الفصل',
  },
];

export default function HSCodesSection() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">التحليل الفني للمنتج وتوضيح HS Code</h2>
        <p className="eden-section-subtitle">
          الهندسة المتقدمة للتصنيف الجمركي والامتثال للأنظمة التجارية (تحديثات 2025)
        </p>
      </div>

      {/* Philosophy Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {classificationPhilosophy.map((item, index) => (
          <div key={index} className="eden-card p-6 hover:shadow-eden-lg transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center mb-4">
              <FileCode className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-lg text-eden-dark mb-2">{item.title}</h3>
            <p className="text-gray-600 text-sm mb-4">{item.description}</p>
            <div className="space-y-2">
              <p className="text-xs font-semibold text-eden-orange">أمثلة:</p>
              <ul className="text-sm text-gray-600 space-y-1">
                {item.examples.map((ex, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-green-500" />
                    {ex}
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-4 p-3 bg-orange-50 rounded-lg">
              <p className="text-xs text-gray-600">
                <Info className="w-3 h-3 inline ml-1" />
                {item.condition}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Critical Warning */}
      <div className="bg-red-50 border-r-4 border-red-500 p-6 rounded-xl">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h3 className="font-bold text-red-700 text-lg mb-2">تحذير حاسم: إشكالية تصنيف البطاطس نصف المقلية</h3>
            <p className="text-gray-700 leading-relaxed">
              تُعد البطاطس نصف المقلية (Frozen Par-fried Potatoes) من أكثر المنتجات تعقيداً في التصنيف الجمركي العالمي، 
              وغالباً ما يقع المصدرون الجدد في فخ تصنيفها كخضروات مجمدة عادية تحت البند <strong>0710.10</strong>.
            </p>
            <p className="text-gray-700 mt-2 leading-relaxed">
              السبب الفني: عملية القلي المبدئي (Par-frying) في الزيت تعتبر "تحضيراً" (Preparation) 
              يتجاوز مجرد الحفظ بالتجميد، مما ينقل المنتج حكماً إلى الفصل <strong>20</strong> 
              تحت البند <strong>2004.10</strong>.
            </p>
          </div>
        </div>
      </div>

      {/* HS Codes Table */}
      <div className="eden-card overflow-hidden">
        <div className="p-6 border-b border-orange-100 bg-gradient-to-r from-orange-50 to-yellow-50">
          <h3 className="font-bold text-xl text-eden-dark">جدول المصفوفة الجمركية الشامل</h3>
          <p className="text-gray-600 text-sm mt-1">Global & Regional HS Codes Matrix</p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="eden-table">
            <thead>
              <tr>
                <th className="text-right">المنتج</th>
                <th className="text-right">HS Code (Global)</th>
                <th className="text-right">الولايات المتحدة (HTSUS)</th>
                <th className="text-right">دول الخليج (GCC 2025)</th>
                <th className="text-right">ملاحظات الامتثال</th>
              </tr>
            </thead>
            <tbody>
              {hsCodesData.map((item, index) => (
                <tr key={index} className={item.warning ? 'bg-red-50/50' : ''}>
                  <td className="font-medium text-gray-800">
                    <div className="flex items-center gap-2">
                      {item.warning && (
                        <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />
                      )}
                      {item.product}
                    </div>
                    {item.warning && (
                      <span className="text-xs text-red-600 block mt-1">
                        {item.warningText}
                      </span>
                    )}
                  </td>
                  <td>
                    <span className="inline-block px-3 py-1 rounded-lg bg-blue-100 text-blue-700 font-mono text-sm">
                      {item.globalCode}
                    </span>
                  </td>
                  <td>
                    <span className="inline-block px-3 py-1 rounded-lg bg-purple-100 text-purple-700 font-mono text-sm">
                      {item.usCode}
                    </span>
                  </td>
                  <td>
                    <span className="inline-block px-3 py-1 rounded-lg bg-green-100 text-green-700 font-mono text-sm">
                      {item.gccCode}
                    </span>
                  </td>
                  <td className="text-gray-600 text-sm">{item.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2025 Updates */}
      <div className="eden-card p-6">
        <h3 className="font-bold text-xl text-eden-dark mb-4 flex items-center gap-2">
          <Info className="w-5 h-5 text-eden-orange" />
          التحديثات الإقليمية الحرجة لعام 2025
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
            <h4 className="font-bold text-blue-800 mb-2">دول مجلس التعاون الخليجي (GCC)</h4>
            <p className="text-sm text-gray-700">
              انتقال دول الخليج نحو تطبيق نظام تكويد موسع يصل إلى <strong>12 رقماً</strong> 
              (بدلاً من 8 أرقام) لزيادة دقة التتبع الجمركي والإحصائي.
            </p>
          </div>
          
          <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
            <h4 className="font-bold text-purple-800 mb-2">الولايات المتحدة الأمريكية</h4>
            <p className="text-sm text-gray-700">
              مع إلغاء بعض الإعفاءات (de minimis exemption) في أغسطس 2025، 
              أصبح الالتزام بكود HTSUS الكامل أمراً إلزامياً.
            </p>
          </div>
          
          <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
            <h4 className="font-bold text-green-800 mb-2">الاتحاد الأوروبي</h4>
            <p className="text-sm text-gray-700">
              يطبق الاتحاد الأوروبي نظامه الخاص (CN Codes) الذي يضيف تفريعات 
              لتمييز المنتجات بناءً على طريقة الطهي والمحتوى النشوي.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
