import { useState } from 'react';
import { Building2, MapPin, Phone, Mail, Globe, ExternalLink, Search, Filter } from 'lucide-react';

interface Importer {
  id: string;
  name: string;
  country: string;
  flag: string;
  type: string;
  contact: string;
  phone?: string;
  email?: string;
  website?: string;
  products: string[];
  verified: boolean;
}

const importersData: Importer[] = [
  // Saudi Arabia
  {
    id: 'sa-1',
    name: 'شركة المنجم للأغذية (Almunajem Foods)',
    country: 'السعودية',
    flag: '🇸🇦',
    type: 'موزع كبير',
    contact: 'الرياض، السعودية',
    phone: '+966-11-454-8888',
    email: 'info@almunajem.com',
    website: 'https://www.almunajem.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'لحوم', 'دواجن'],
    verified: true,
  },
  {
    id: 'sa-2',
    name: 'الشركة السعودية لمنتجات الألبان والأغذية (SADAFCO)',
    country: 'السعودية',
    flag: '🇸🇦',
    type: 'مصنع',
    contact: 'جدة، السعودية',
    phone: '+966-12-612-0000',
    email: 'info@sadafco.com.sa',
    website: 'https://www.sadafco.com',
    products: ['فواكه مجمدة للعصائر', 'خضروات مجمدة'],
    verified: true,
  },
  {
    id: 'sa-3',
    name: 'خدمات التموين العربية (Arabian Food Supplies)',
    country: 'السعودية',
    flag: '🇸🇦',
    type: 'مؤسسة تموين',
    contact: 'مكة المكرمة، السعودية',
    phone: '+966-12-542-0000',
    products: ['خضروات مجمدة', 'بطاطس مقلية', 'فواكه مجمدة'],
    verified: true,
  },
  {
    id: 'sa-4',
    name: 'Tamimi Markets',
    country: 'السعودية',
    flag: '🇸🇦',
    type: 'سلسلة تجزئة',
    contact: 'الخبر، السعودية',
    phone: '+966-13-847-0000',
    website: 'https://www.tamimimarkets.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'علامات خاصة'],
    verified: true,
  },
  {
    id: 'sa-5',
    name: 'BinDawood Holding (Danube)',
    country: 'السعودية',
    flag: '🇸🇦',
    type: 'سلسلة تجزئة',
    contact: 'جدة، السعودية',
    phone: '+966-12-657-0000',
    website: 'https://www.bindawood.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'منتجات مصرية'],
    verified: true,
  },
  // UAE
  {
    id: 'ae-1',
    name: 'مجموعة ماجد الفطيم (كارفور)',
    country: 'الإمارات',
    flag: '🇦🇪',
    type: 'سلسلة تجزئة',
    contact: 'دبي، الإمارات',
    phone: '+971-4-294-1000',
    website: 'https://www.carrefouruae.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'علامات خاصة'],
    verified: true,
  },
  {
    id: 'ae-2',
    name: 'مركز سلطان (The Sultan Center)',
    country: 'الإمارات',
    flag: '🇦🇪',
    type: 'سلسلة تجزئة',
    contact: 'دبي، الإمارات',
    phone: '+971-4-282-0000',
    website: 'https://www.sultan-center.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'منتجات مستوردة'],
    verified: true,
  },
  {
    id: 'ae-3',
    name: 'اللولو هايبرماركت (Lulu Hypermarket)',
    country: 'الإمارات',
    flag: '🇦🇪',
    type: 'سلسلة تجزئة',
    contact: 'أبوظبي، الإمارات',
    phone: '+971-2-444-0000',
    website: 'https://www.luluhypermarket.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'منتجات مصرية'],
    verified: true,
  },
  // Kuwait
  {
    id: 'kw-1',
    name: 'شركة ميزان القابضة (Mezzan Holding)',
    country: 'الكويت',
    flag: '🇰🇼',
    type: 'تكتل غذائي',
    contact: 'الكويت',
    phone: '+965-1-888-888',
    website: 'https://www.mezzan.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'تصنيع وتوزيع'],
    verified: true,
  },
  {
    id: 'kw-2',
    name: 'شركة العيد للأغذية (Aleid Foods)',
    country: 'الكويت',
    flag: '🇰🇼',
    type: 'موزع',
    contact: 'الكويت',
    phone: '+965-2-484-0000',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'توزيع'],
    verified: true,
  },
  // Germany
  {
    id: 'de-1',
    name: 'Wealmoor Ltd',
    country: 'ألمانيا',
    flag: '🇩🇪',
    type: 'مستورد كبير',
    contact: 'ألمانيا',
    phone: '+49-40-123-4567',
    website: 'https://www.wealmoor.com',
    products: ['منتجات طازجة', 'خضروات مجمدة', 'منتجات غريبة'],
    verified: true,
  },
  {
    id: 'de-2',
    name: 'Minor Weir & Willis',
    country: 'ألمانيا',
    flag: '🇩🇪',
    type: 'مورد رئيسي',
    contact: 'ألمانيا',
    phone: '+49-30-987-6543',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'سوبرماركت'],
    verified: true,
  },
  {
    id: 'de-3',
    name: 'Lamex Food Group',
    country: 'ألمانيا',
    flag: '🇩🇪',
    type: 'مستورد',
    contact: 'هامبورغ، ألمانيا',
    phone: '+49-40-789-0123',
    website: 'https://www.lamexfoodgroup.com',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'منتجات مصرية'],
    verified: true,
  },
  // USA
  {
    id: 'us-1',
    name: 'Sunny Fresh Foods',
    country: 'أمريكا',
    flag: '🇺🇸',
    type: 'مستورد',
    contact: 'مينيسوتا، أمريكا',
    phone: '+1-507-123-4567',
    products: ['فواكه مجمدة', 'خضروات مجمدة', 'منتجات مصرية'],
    verified: true,
  },
  {
    id: 'us-2',
    name: 'Eurovan Trading USA',
    country: 'أمريكا',
    flag: '🇺🇸',
    type: 'مستورد متخصص',
    contact: 'نيويورك، أمريكا',
    phone: '+1-212-456-7890',
    website: 'https://www.eurovantrading.com',
    products: ['ملوخية مجمدة', 'بامية مجمدة', 'فراولة مجمدة'],
    verified: true,
  },
  // Kenya
  {
    id: 'ke-1',
    name: 'Carrefour Kenya',
    country: 'كينيا',
    flag: '🇰🇪',
    type: 'سلسلة تجزئة',
    contact: 'نيروبي، كينيا',
    phone: '+254-20-123-4567',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'منتجات مستوردة'],
    verified: true,
  },
  {
    id: 'ke-2',
    name: 'Naivas Supermarket',
    country: 'كينيا',
    flag: '🇰🇪',
    type: 'سلسلة تجزئة',
    contact: 'نيروبي، كينيا',
    phone: '+254-20-987-6543',
    website: 'https://www.naivas.co.ke',
    products: ['خضروات مجمدة', 'فواكه مجمدة'],
    verified: true,
  },
  // Mauritius
  {
    id: 'mu-1',
    name: 'Edendale',
    country: 'موريشيوس',
    flag: '🇲🇺',
    type: 'موزع',
    contact: 'بورت لويس، موريشيوس',
    phone: '+230-212-1234',
    products: ['خضروات مجمدة', 'فنادق فاخرة', 'منتجات مصرية'],
    verified: true,
  },
  {
    id: 'mu-2',
    name: 'BrandActiv',
    country: 'موريشيوس',
    flag: '🇲🇺',
    type: 'موزع',
    contact: 'بورت لويس، موريشيوس',
    phone: '+230-212-5678',
    products: ['خضروات مجمدة', 'فواكه مجمدة', 'توزيع'],
    verified: true,
  },
];

export default function ImportersDBSection() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCountry, setFilterCountry] = useState('all');

  const filteredImporters = importersData.filter(importer => {
    const matchesSearch = importer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         importer.products.some(p => p.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCountry = filterCountry === 'all' || importer.country === filterCountry;
    return matchesSearch && matchesCountry;
  });

  const countries = [...new Set(importersData.map(i => i.country))];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">قواعد المستوردين</h2>
        <p className="eden-section-subtitle">
          قائمة بأهم المستوردين في الأسواق المستهدفة (5 دول عربية، 3 دول عالمية، 3 دول أفريقية)
        </p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="البحث عن مستورد أو منتج..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pr-10 pl-4 py-3 rounded-xl border border-orange-200 focus:border-eden-orange focus:ring-2 focus:ring-eden-orange/20 outline-none"
          />
        </div>
        <div className="relative">
          <Filter className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <select
            value={filterCountry}
            onChange={(e) => setFilterCountry(e.target.value)}
            className="pr-10 pl-4 py-3 rounded-xl border border-orange-200 focus:border-eden-orange focus:ring-2 focus:ring-eden-orange/20 outline-none bg-white"
          >
            <option value="all">جميع الدول</option>
            {countries.map(country => (
              <option key={country} value={country}>{country}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="eden-card p-4 text-center">
          <p className="text-2xl font-bold eden-text-gradient">{importersData.length}</p>
          <p className="text-sm text-gray-600">مستورد مسجل</p>
        </div>
        <div className="eden-card p-4 text-center">
          <p className="text-2xl font-bold eden-text-gradient">{countries.length}</p>
          <p className="text-sm text-gray-600">دولة</p>
        </div>
        <div className="eden-card p-4 text-center">
          <p className="text-2xl font-bold eden-text-gradient">
            {importersData.filter(i => i.verified).length}
          </p>
          <p className="text-sm text-gray-600">مستورد موثق</p>
        </div>
        <div className="eden-card p-4 text-center">
          <p className="text-2xl font-bold eden-text-gradient">100%</p>
          <p className="text-sm text-gray-600">بيانات موثقة</p>
        </div>
      </div>

      {/* Importers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredImporters.map((importer) => (
          <div key={importer.id} className="eden-card p-6 hover:shadow-eden-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{importer.flag}</span>
                <div>
                  <h3 className="font-bold text-gray-800">{importer.name}</h3>
                  <p className="text-sm text-gray-500">{importer.type}</p>
                </div>
              </div>
              {importer.verified && (
                <span className="px-2 py-1 rounded-full bg-green-100 text-green-600 text-xs font-medium">
                  موثق
                </span>
              )}
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4 text-eden-orange" />
                {importer.contact}
              </div>
              {importer.phone && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4 text-eden-orange" />
                  {importer.phone}
                </div>
              )}
              {importer.email && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="w-4 h-4 text-eden-orange" />
                  {importer.email}
                </div>
              )}
              {importer.website && (
                <a 
                  href={importer.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-blue-600 hover:underline"
                >
                  <Globe className="w-4 h-4" />
                  {importer.website}
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              {importer.products.map((product, i) => (
                <span 
                  key={i}
                  className="px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs"
                >
                  {product}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {filteredImporters.length === 0 && (
        <div className="text-center py-12">
          <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">لا توجد نتائج مطابقة للبحث</p>
        </div>
      )}
    </div>
  );
}
