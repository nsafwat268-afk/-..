import { Thermometer, MapPin, AlertTriangle, CheckCircle } from 'lucide-react';

const shippingRoutes = [
  {
    destination: 'روسيا (نوفوروسيسك)',
    flag: '🇷🇺',
    port: 'السويس / الدخيلة',
    transitTime: '10-14 يوم',
    cost: '1,250-1,550 $',
    notes: 'المسار الأسرع والأرخص',
    recommended: true,
  },
  {
    destination: 'هولندا (روتردام)',
    flag: '🇳🇱',
    port: 'الإسكندرية',
    transitTime: '12-16 يوم',
    cost: '1,800-2,200 $',
    notes: 'خدمات منتظمة وموثوقة',
    recommended: true,
  },
  {
    destination: 'ألمانيا (هامبورغ)',
    flag: '🇩🇪',
    port: 'الإسكندرية',
    transitTime: '14-18 يوم',
    cost: '2,000-2,400 $',
    notes: 'تكاليف تفريغ مرتفعة',
    recommended: true,
  },
  {
    destination: 'المملكة المتحدة',
    flag: '🇬🇧',
    port: 'الإسكندرية',
    transitTime: '14-18 يوم',
    cost: '2,200-2,800 $',
    notes: 'خدمات منتظمة',
    recommended: true,
  },
  {
    destination: 'السعودية (جدة)',
    flag: '🇸🇦',
    port: 'السويس / السخنة',
    transitTime: '5-8 أيام',
    cost: '1,000-1,400 $',
    notes: 'سريع جداً',
    recommended: true,
  },
  {
    destination: 'الإمارات (جبل علي)',
    flag: '🇦🇪',
    port: 'السخنة',
    transitTime: '5-7 أيام',
    cost: '1,000-1,400 $',
    notes: 'مركز لإعادة التصدير',
    recommended: true,
  },
  {
    destination: 'كينيا (مومباسا)',
    flag: '🇰🇪',
    port: 'الإسكندرية / السخنة',
    transitTime: '30-35 يوم',
    cost: '2,000-2,500 $',
    notes: 'مدة طويلة - أجهزة تبريد موثوقة مطلوبة',
    recommended: false,
  },
  {
    destination: 'موريشيوس',
    flag: '🇲🇺',
    port: 'الإسكندرية',
    transitTime: '40-45 يوم',
    cost: '3,000-3,500 $',
    notes: 'ترانزيت محتمل - تكلفة عالية',
    recommended: false,
  },
];

const coldChainRequirements = [
  {
    title: 'درجة الحرارة',
    value: '-18°C',
    icon: Thermometer,
    description: 'يجب الحفاظ على درجة حرارة ثابتة طوال الرحلة',
  },
  {
    title: 'أجهزة التتبع',
    value: 'Data Loggers',
    icon: CheckCircle,
    description: 'تسجيل درجات الحرارة في كل حاوية',
  },
  {
    title: 'التأمين',
    value: 'إلزامي',
    icon: CheckCircle,
    description: 'تغطية كاملة للشحنة ضد التلف',
  },
  {
    title: 'الفحص',
    value: 'قبل الشحن',
    icon: CheckCircle,
    description: 'فحص الحاويات المبردة قبل التحميل',
  },
];

export default function LogisticsSection() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">اللوجيستيات وسلاسل الإمداد</h2>
        <p className="eden-section-subtitle">
          تحليل مسارات الشحن وتكاليفه ومتطلبات سلسلة التبريد
        </p>
      </div>

      {/* Cold Chain */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {coldChainRequirements.map((item, index) => {
          const Icon = item.icon;
          return (
            <div key={index} className="eden-card p-6 text-center">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-eden-orange to-eden-amber flex items-center justify-center mx-auto mb-4">
                <Icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="font-bold text-lg text-eden-dark">{item.title}</h3>
              <p className="text-2xl font-bold eden-text-gradient mt-2">{item.value}</p>
              <p className="text-sm text-gray-600 mt-2">{item.description}</p>
            </div>
          );
        })}
      </div>

      {/* Shipping Routes Table */}
      <div className="eden-card overflow-hidden">
        <div className="p-6 border-b border-orange-100 bg-gradient-to-r from-orange-50 to-yellow-50">
          <h3 className="font-bold text-xl text-eden-dark">جدول مسارات الشحن البحري</h3>
          <p className="text-gray-600 text-sm mt-1">تقديرات 2025 - حاويات مبردة (Reefer 40ft)</p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="eden-table">
            <thead>
              <tr>
                <th>الوجهة</th>
                <th>ميناء المغادرة</th>
                <th>مدة العبور</th>
                <th>التكلفة</th>
                <th>ملاحظات</th>
              </tr>
            </thead>
            <tbody>
              {shippingRoutes.map((route, index) => (
                <tr key={index} className={route.recommended ? 'bg-green-50/50' : ''}>
                  <td className="font-medium">
                    <div className="flex items-center gap-2">
                      <span>{route.flag}</span>
                      {route.destination}
                      {route.recommended && (
                        <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-600 text-xs">
                          موصى به
                        </span>
                      )}
                    </div>
                  </td>
                  <td>{route.port}</td>
                  <td>{route.transitTime}</td>
                  <td className="font-bold text-eden-orange">{route.cost}</td>
                  <td className="text-gray-600 text-sm">{route.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Egyptian Ports */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="eden-card p-6">
          <div className="flex items-center gap-3 mb-4">
            <MapPin className="w-6 h-6 text-eden-orange" />
            <h3 className="font-bold text-lg">ميناء الإسكندرية</h3>
          </div>
          <ul className="space-y-2 text-gray-700">
            <li>• أكبر ميناء في مصر</li>
            <li>• خدمات منتظمة لأوروبا</li>
            <li>• بنية تحتية متطورة</li>
            <li>• تخزين مبرد متاح</li>
          </ul>
        </div>

        <div className="eden-card p-6">
          <div className="flex items-center gap-3 mb-4">
            <MapPin className="w-6 h-6 text-eden-orange" />
            <h3 className="font-bold text-lg">ميناء دمياط</h3>
          </div>
          <ul className="space-y-2 text-gray-700">
            <li>• تخصص في الحبوب والبضائع</li>
            <li>• خدمات لأوروبا وآسيا</li>
            <li>• تكاليف تنافسية</li>
            <li>• توسعات حديثة</li>
          </ul>
        </div>

        <div className="eden-card p-6">
          <div className="flex items-center gap-3 mb-4">
            <MapPin className="w-6 h-6 text-eden-orange" />
            <h3 className="font-bold text-lg">ميناء السخنة</h3>
          </div>
          <ul className="space-y-2 text-gray-700">
            <li>• أقرب ميناء للخليج</li>
            <li>• مدة شحن قصيرة</li>
            <li>• خدمات سريعة</li>
            <li>• تكاليف منخفضة</li>
          </ul>
        </div>
      </div>

      {/* Challenges */}
      <div className="bg-red-50 border-r-4 border-red-500 p-6 rounded-xl">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h3 className="font-bold text-red-700 text-lg mb-2">التحديات اللوجستية</h3>
            <ul className="space-y-2 text-gray-700">
              <li>• الحفاظ على سلسلة التبريد (-18°C) طوال الرحلة</li>
              <li>• أي تذبذب في درجة الحرارة يؤدي إلى تبلور المنتج ورفضه</li>
              <li>• تكاليف الشحن المرتفعة للأسواق البعيدة (أفريقيا)</li>
              <li>• مخاطر التأخير في الموانئ الأوروبية بسبب الفحص</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-2xl text-white">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-xl mb-2">توصيات اللوجيستيات</h3>
            <ul className="space-y-2 text-white/90">
              <li>• الاستثمار في أجهزة تسجيل درجات الحرارة (Data Loggers)</li>
              <li>• التعاقد مع خطوط ملاحية موثوقة توفر حاويات مبردة حديثة</li>
              <li>• التأمين الكامل على جميع الشحنات</li>
              <li>• تنويع المسارات لتجنب الاعتماد على ميناء واحد</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
