import { useState } from 'react';
import { 
  Building2, 
  FileCheck, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign,
  Ship,
  Shield,
  MapPin,
  Globe
} from 'lucide-react';

// Country data with detailed analysis
const countriesData = {
  global: [
    {
      id: 'germany',
      name: 'ألمانيا',
      flag: '🇩🇪',
      importValue: 196.14,
      growth: 56.76,
      marketShare: 42.4,
      swot: {
        strengths: ['سوق كبير ومنظم', 'قدرة شرائية عالية', 'بنية تحتية متطورة'],
        weaknesses: ['متطلبات جودة صارمة', 'منافسة شديدة', 'تكاليف شحن مرتفعة'],
        opportunities: ['نقص الإنتاج الأوروبي', 'طلب على المنتجات العضوية', 'اتفاقيات تجارية'],
        threats: ['تشديد قواعد المبيدات', 'منافسة بولندا', 'تقلبات مناخية']
      },
      requirements: [
        'شهادة GlobalGAP للمزارع',
        'شهادة BRCGS للمصنع',
        'تحليل متبقيات المبيدات (MRLs)',
        'الامتثال للائحة PPWR للتغليف',
        'تسجيل في نظام TRACES'
      ],
      competitors: [
        { name: 'جرينيارد (بلجيكا)', share: '25%', price: '2.8-3.5€/kg' },
        { name: 'بوندويل (فرنسا)', share: '18%', price: '3.0-4.0€/kg' },
        { name: 'نوماد فودز (هولندا)', share: '15%', price: '2.5-3.2€/kg' }
      ],
      pricing: {
        retail: '3.5-4.5 €/kg',
        wholesale: '2.38-3.68 $/kg',
        industrial: '1.6-2.2 $/kg'
      },
      logistics: {
        port: 'ميناء هامبورغ / روتردام',
        transitTime: '12-16 يوم',
        shippingCost: '1,800-2,200 $/حاوية',
        coldStorage: 'متاح بكثرة'
      }
    },
    {
      id: 'usa',
      name: 'الولايات المتحدة',
      flag: '🇺🇸',
      importValue: 185.3,
      growth: 12.4,
      marketShare: 8.2,
      swot: {
        strengths: ['سوق ضخم', 'طلب على المنتجات العضوية', 'قدرة شرائية عالية'],
        weaknesses: ['متطلبات FDA صارمة', 'رسوم جمركية محتملة', 'بعد جغرافي'],
        opportunities: ['نمو قطاع السموذي', 'طلب على البطاطس المجمدة', 'سوق العلامات الخاصة'],
        threats: ['حروب تجارية', 'تقلبات العملة', 'منافسة المحليين']
      },
      requirements: [
        'تسجيل FDA (FSMA)',
        'نظام HACCP معتمد',
        'شهادة Kosher/Halal',
        'تحليل مخاطر نقاط التحكم الحرجة',
        'تتبع الشحنات رقمياً'
      ],
      competitors: [
        { name: 'McCain Foods', share: '30%', price: '2.5-3.5$/lb' },
        { name: 'Lamb Weston', share: '25%', price: '2.8-3.8$/lb' },
        { name: 'Simplot', share: '20%', price: '2.2-3.0$/lb' }
      ],
      pricing: {
        retail: '3.5-5.0 $/lb',
        wholesale: '2.0-3.0 $/lb',
        industrial: '1.5-2.0 $/lb'
      },
      logistics: {
        port: 'ميناء نيويورك / لوس أنجلوس',
        transitTime: '18-25 يوم',
        shippingCost: '2,500-3,500 $/حاوية',
        coldStorage: 'متاح'
      }
    },
    {
      id: 'uk',
      name: 'المملكة المتحدة',
      flag: '🇬🇧',
      importValue: 128.5,
      growth: 6.2,
      marketShare: 6.1,
      swot: {
        strengths: ['اتفاقية شراكة مع مصر', 'سوق منظم', 'طلب على المنتجات المصرية'],
        weaknesses: ['بريكست وتعقيداته', 'تكاليف شحن مرتفعة', 'منافسة المحليين'],
        opportunities: ['اتفاقية تجارية تفضيلية', 'سوق العلامات الخاصة', 'قطاع HORECA'],
        threats: ['تشديد الضوابط', 'تقلبات العملة', 'منافسة أوروبا']
      },
      requirements: [
        'شهادة BRCGS',
        'الامتثال لمعايير UK',
        'تتبع سلسلة التوريد',
        'تحليل متبقيات المبيدات',
        'شهادة الصحة النباتية'
      ],
      competitors: [
        { name: 'Wealmoor Ltd', share: '15%', price: '2.5-3.5£/kg' },
        { name: 'Minor Weir & Willis', share: '12%', price: '2.8-3.8£/kg' },
        { name: 'Barfoots of Botley', share: '10%', price: '3.0-4.0£/kg' }
      ],
      pricing: {
        retail: '3.0-4.5 £/kg',
        wholesale: '2.0-3.0 £/kg',
        industrial: '1.5-2.0 £/kg'
      },
      logistics: {
        port: 'ميناء لندن / فيلكستو',
        transitTime: '14-18 يوم',
        shippingCost: '2,200-2,800 $/حاوية',
        coldStorage: 'متاح'
      }
    }
  ],
  arab: [
    {
      id: 'saudi',
      name: 'المملكة العربية السعودية',
      flag: '🇸🇦',
      importValue: 491,
      growth: 23,
      marketShare: 35,
      swot: {
        strengths: ['سوق ضخم', 'قرب جغرافي', 'علاقات قوية مع مصر', 'رؤية 2030'],
        weaknesses: ['متطلبات SFDA صارمة', 'منافسة محلية', 'تقلبات موسمية'],
        opportunities: ['نمو قطاع HORECA', 'توسع السياحة', 'سكان متزايد'],
        threats: ['تشديد اللوائح', 'منافسة دول أخرى', 'تقلبات أسعار النفط']
      },
      requirements: [
        'شهادة المطابقة (CoC) من SFDA',
        'تسجيل المنتجات على منصة "غد"',
        'شهادة الحلال (للمنتجات الحيوانية)',
        'تحديث بيانات التغذية (يوليو 2025)',
        'شهادة الصحة النباتية'
      ],
      competitors: [
        { name: 'المنجم للأغذية', share: '25%', price: '12-18 ريال/كجم' },
        { name: 'المراعي', share: '20%', price: '15-22 ريال/كجم' },
        { name: 'سدافكو', share: '15%', price: '14-20 ريال/كجم' }
      ],
      pricing: {
        retail: '15-25 ريال/كجم',
        wholesale: '10-15 ريال/كجم',
        industrial: '8-12 ريال/كجم'
      },
      logistics: {
        port: 'ميناء جدة / الدمام',
        transitTime: '5-8 أيام',
        shippingCost: '1,200-1,600 $/حاوية',
        coldStorage: 'متطور ومتوفر'
      }
    },
    {
      id: 'uae',
      name: 'الإمارات العربية المتحدة',
      flag: '🇦🇪',
      importValue: 285,
      growth: 18,
      marketShare: 22,
      swot: {
        strengths: ['مركز إعادة التصدير', 'بنية تحتية متطورة', 'قرب جغرافي'],
        weaknesses: ['سوق صغير نسبياً', 'منافسة شديدة', 'تكاليف مرتفعة'],
        opportunities: ['إعادة التصدير لدول الخليج', 'سوق HORECA', 'التجارة الإلكترونية'],
        threats: ['منافسة دبي كمستورد', 'تقلبات اقتصادية', 'تشديد اللوائح']
      },
      requirements: [
        'شهادة المطابقة من ESMA',
        'تسجيل في نظام ECAS',
        'شهادة الحلال',
        'ملصق المنتج بالعربية والإنجليزية',
        'شهادة المنشأ'
      ],
      competitors: [
        { name: 'مجموعة ماجد الفطيم', share: '30%', price: '10-15 درهم/كجم' },
        { name: 'مركز سلطان', share: '20%', price: '12-18 درهم/كجم' },
        { name: 'اللولو هايبر', share: '18%', price: '11-16 درهم/كجم' }
      ],
      pricing: {
        retail: '12-20 درهم/كجم',
        wholesale: '8-12 درهم/كجم',
        industrial: '6-10 درهم/كجم'
      },
      logistics: {
        port: 'ميناء جبل علي',
        transitTime: '5-7 أيام',
        shippingCost: '1,000-1,400 $/حاوية',
        coldStorage: 'متطور جداً'
      }
    },
    {
      id: 'kuwait',
      name: 'الكويت',
      flag: '🇰🇼',
      importValue: 142,
      growth: 15,
      marketShare: 12,
      swot: {
        strengths: ['سوق واعد', 'قدرة شرائية عالية', 'قرب جغرافي'],
        weaknesses: ['سوق صغير', 'منافسة شديدة', 'تعقيدات جمركية'],
        opportunities: ['نمو الطبقة الوسطى', 'توسع سلاسل التجزئة', 'طلب على المنتجات المصرية'],
        threats: ['منافسة دول أخرى', 'تقلبات اقتصادية', 'تشديد اللوائح']
      },
      requirements: [
        'شهادة المطابقة من PAHW',
        'شهادة الحلال',
        'ملصق المنتج بالعربية',
        'شهادة الصحة النباتية',
        'شهادة المنشأ'
      ],
      competitors: [
        { name: 'شركة ميزان', share: '25%', price: '0.9-1.2 د.ك/كجم' },
        { name: 'مركز سلطان', share: '20%', price: '1.0-1.3 د.ك/كجم' },
        { name: 'العيد للأغذية', share: '15%', price: '0.95-1.25 د.ك/كجم' }
      ],
      pricing: {
        retail: '1.0-1.5 د.ك/كجم',
        wholesale: '0.7-1.0 د.ك/كجم',
        industrial: '0.5-0.8 د.ك/كجم'
      },
      logistics: {
        port: 'ميناء الشويخ',
        transitTime: '6-9 أيام',
        shippingCost: '1,100-1,500 $/حاوية',
        coldStorage: 'متاح'
      }
    },
    {
      id: 'qatar',
      name: 'قطر',
      flag: '🇶🇦',
      importValue: 98,
      growth: 22,
      marketShare: 8,
      swot: {
        strengths: ['نمو سريع', 'قدرة شرائية عالية', 'استعدادات كأس العالم'],
        weaknesses: ['سوق صغير', 'منافسة شديدة', 'تعقيدات جمركية'],
        opportunities: ['قطاع HORECA', 'سوق العلامات الخاصة', 'طلب على المنتجات المصرية'],
        threats: ['منافسة دول أخرى', 'تقلبات اقتصادية', 'تشديد اللوائح']
      },
      requirements: [
        'شهادة المطابقة من QS',
        'شهادة الحلال',
        'ملصق المنتج بالعربية والإنجليزية',
        'شهادة الصحة النباتية',
        'شهادة المنشأ'
      ],
      competitors: [
        { name: 'Monoprix Qatar', share: '20%', price: '12-18 ريال/كجم' },
        { name: 'Carrefour Qatar', share: '18%', price: '14-20 ريال/كجم' },
        { name: 'Lulu Qatar', share: '15%', price: '13-19 ريال/كجم' }
      ],
      pricing: {
        retail: '15-22 ريال/كجم',
        wholesale: '10-15 ريال/كجم',
        industrial: '8-12 ريال/كجم'
      },
      logistics: {
        port: 'ميناء حمد',
        transitTime: '7-10 أيام',
        shippingCost: '1,300-1,700 $/حاوية',
        coldStorage: 'متاح'
      }
    },
    {
      id: 'oman',
      name: 'عمان',
      flag: '🇴🇲',
      importValue: 76,
      growth: 12,
      marketShare: 6,
      swot: {
        strengths: ['سوق مستقر', 'قرب جغرافي', 'علاقات قوية مع مصر'],
        weaknesses: ['سوق صغير', 'منافسة شديدة', 'بنية تحتية محدودة'],
        opportunities: ['نمو الطبقة الوسطى', 'توسع سلاسل التجزئة', 'طلب على المنتجات المصرية'],
        threats: ['منافسة دول أخرى', 'تقلبات اقتصادية', 'تشديد اللوائح']
      },
      requirements: [
        'شهادة المطابقة من MOCI',
        'شهادة الحلال',
        'ملصق المنتج بالعربية',
        'شهادة الصحة النباتية',
        'شهادة المنشأ'
      ],
      competitors: [
        { name: 'Lulu Oman', share: '25%', price: '1.0-1.5 ر.ع/كجم' },
        { name: 'Carrefour Oman', share: '20%', price: '1.2-1.7 ر.ع/كجم' }
      ],
      pricing: {
        retail: '1.2-1.8 ر.ع/كجم',
        wholesale: '0.8-1.2 ر.ع/كجم',
        industrial: '0.6-1.0 ر.ع/كجم'
      },
      logistics: {
        port: 'ميناء صحار',
        transitTime: '6-8 أيام',
        shippingCost: '1,200-1,600 $/حاوية',
        coldStorage: 'متاح'
      }
    }
  ],
  african: [
    {
      id: 'kenya',
      name: 'كينيا',
      flag: '🇰🇪',
      importValue: 45,
      growth: 28,
      marketShare: 42,
      swot: {
        strengths: ['سوق شرق أفريقيا الرئيسي', 'نمو سريع', 'ميزة الكوميسا'],
        weaknesses: ['بنية تحتية ضعيفة', 'تكاليف شحن مرتفعة', 'منافسة محلية'],
        opportunities: ['نمو الطبقة الوسطى', 'توسع سلاسل التجزئة', 'اتفاقية الكوميسا'],
        threats: ['منافسة دول أخرى', 'تقلبات اقتصادية', 'تحديات لوجستية']
      },
      requirements: [
        'شهادة المنشأ من الكوميسا',
        'شهادة الصحة النباتية',
        'فاتورة تجارية موثقة',
        'قائمة التعبئة',
        'شهادة الجودة'
      ],
      competitors: [
        { name: 'Carrefour Kenya', share: '20%', price: '200-300 شيلنج/كجم' },
        { name: 'Naivas', share: '18%', price: '220-320 شيلنج/كجم' }
      ],
      pricing: {
        retail: '250-350 شيلنج/كجم',
        wholesale: '180-250 شيلنج/كجم',
        industrial: '150-200 شيلنج/كجم'
      },
      logistics: {
        port: 'ميناء مومباسا',
        transitTime: '30-35 يوم',
        shippingCost: '2,000-2,500 $/حاوية',
        coldStorage: 'محدود'
      }
    },
    {
      id: 'mauritius',
      name: 'موريشيوس',
      flag: '🇲🇺',
      importValue: 32,
      growth: 19,
      marketShare: 30,
      swot: {
        strengths: ['سوق سياحي راقٍ', 'قدرة شرائية عالية', 'ميزة الكوميسا'],
        weaknesses: ['سوق صغير', 'بعد جغرافي', 'تكاليف شحن مرتفعة'],
        opportunities: ['قطاع الفنادق الفاخرة', 'سوق العلامات الخاصة', 'اتفاقية الكوميسا'],
        threats: ['منافسة دول أخرى', 'تقلبات سياحية', 'تحديات لوجستية']
      },
      requirements: [
        'شهادة المنشأ من الكوميسا',
        'شهادة الصحة النباتية',
        'فاتورة تجارية موثقة',
        'شهادة الجودة',
        'تأمين الشحنة'
      ],
      competitors: [
        { name: 'Edendale', share: '25%', price: '80-120 روبية/كجم' },
        { name: 'BrandActiv', share: '20%', price: '90-130 روبية/كجم' }
      ],
      pricing: {
        retail: '100-150 روبية/كجم',
        wholesale: '70-100 روبية/كجم',
        industrial: '50-80 روبية/كجم'
      },
      logistics: {
        port: 'ميناء بورت لويس',
        transitTime: '40-45 يوم',
        shippingCost: '3,000-3,500 $/حاوية',
        coldStorage: 'محدود'
      }
    },
    {
      id: 'southafrica',
      name: 'جنوب أفريقيا',
      flag: '🇿🇦',
      importValue: 28,
      growth: 14,
      marketShare: 28,
      swot: {
        strengths: ['سوق كبير', 'بنية تحتية متطورة', 'ميزة الكوميسا'],
        weaknesses: ['منافسة محلية شديدة', 'تعقيدات جمركية', 'بعد جغرافي'],
        opportunities: ['نمو الطبقة الوسطى', 'توسع سلاسل التجزئة', 'اتفاقية الكوميسا'],
        threats: ['منافسة دول أخرى', 'تقلبات اقتصادية', 'تحديات لوجستية']
      },
      requirements: [
        'شهادة المنشأ من الكوميسا',
        'شهادة الصحة النباتية',
        'فاتورة تجارية موثقة',
        'شهادة الجودة',
        'تأمين الشحنة'
      ],
      competitors: [
        { name: 'Shoprite', share: '30%', price: '25-35 راند/كجم' },
        { name: 'Pick n Pay', share: '25%', price: '28-38 راند/كجم' }
      ],
      pricing: {
        retail: '30-45 راند/كجم',
        wholesale: '22-30 راند/كجم',
        industrial: '18-25 راند/كجم'
      },
      logistics: {
        port: 'ميناء ديربان',
        transitTime: '25-30 يوم',
        shippingCost: '2,500-3,000 $/حاوية',
        coldStorage: 'متاح'
      }
    }
  ]
};

export default function CountryAnalysisSection() {
  const [activeTab, setActiveTab] = useState<'global' | 'arab' | 'african'>('global');
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);

  const currentCountries = countriesData[activeTab];
  const selectedCountryData = selectedCountry 
    ? currentCountries.find(c => c.id === selectedCountry)
    : null;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="eden-section-title text-3xl">التحليل الداخلي للأسواق المستهدفة</h2>
        <p className="eden-section-subtitle">
          تحليل شامل لأكبر 3 دول مستوردة عالمياً، 5 دول عربية، و3 دول أفريقية
        </p>
      </div>

      {/* Tabs */}
      <div className="flex justify-center gap-4 mb-6">
        <button
          onClick={() => { setActiveTab('global'); setSelectedCountry(null); }}
          className={`px-6 py-3 rounded-xl font-semibold transition-all ${
            activeTab === 'global'
              ? 'bg-gradient-to-r from-eden-orange to-eden-amber text-white shadow-eden'
              : 'bg-white text-gray-600 hover:bg-orange-50'
          }`}
        >
          <span className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            الدول العالمية
          </span>
        </button>
        <button
          onClick={() => { setActiveTab('arab'); setSelectedCountry(null); }}
          className={`px-6 py-3 rounded-xl font-semibold transition-all ${
            activeTab === 'arab'
              ? 'bg-gradient-to-r from-eden-orange to-eden-amber text-white shadow-eden'
              : 'bg-white text-gray-600 hover:bg-orange-50'
          }`}
        >
          <span className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            الدول العربية
          </span>
        </button>
        <button
          onClick={() => { setActiveTab('african'); setSelectedCountry(null); }}
          className={`px-6 py-3 rounded-xl font-semibold transition-all ${
            activeTab === 'african'
              ? 'bg-gradient-to-r from-eden-orange to-eden-amber text-white shadow-eden'
              : 'bg-white text-gray-600 hover:bg-orange-50'
          }`}
        >
          <span className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            الدول الأفريقية
          </span>
        </button>
      </div>

      {/* Country Cards */}
      {!selectedCountry && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {currentCountries.map((country) => (
            <button
              key={country.id}
              onClick={() => setSelectedCountry(country.id)}
              className="eden-card p-6 text-right hover:shadow-eden-lg transition-all"
            >
              <div className="flex items-center gap-4 mb-4">
                <span className="text-4xl">{country.flag}</span>
                <div className="flex-1">
                  <h3 className="font-bold text-xl text-eden-dark">{country.name}</h3>
                  <p className="text-sm text-gray-500">انقر للتفاصيل الكاملة</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-orange-50 rounded-lg">
                  <p className="text-2xl font-bold eden-text-gradient">{country.importValue}M$</p>
                  <p className="text-xs text-gray-600">قيمة الواردات</p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">+{country.growth}%</p>
                  <p className="text-xs text-gray-600">معدل النمو</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Country Details */}
      {selectedCountryData && (
        <div className="space-y-6">
          <button
            onClick={() => setSelectedCountry(null)}
            className="eden-btn-primary flex items-center gap-2"
          >
            ← العودة للقائمة
          </button>

          {/* Country Header */}
          <div className="eden-card p-8">
            <div className="flex items-center gap-6">
              <span className="text-6xl">{selectedCountryData.flag}</span>
              <div className="flex-1">
                <h3 className="text-3xl font-bold text-eden-dark">{selectedCountryData.name}</h3>
                <div className="flex gap-6 mt-4">
                  <div>
                    <p className="text-3xl font-bold eden-text-gradient">{selectedCountryData.importValue}M$</p>
                    <p className="text-sm text-gray-600">قيمة الواردات</p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-green-600">+{selectedCountryData.growth}%</p>
                    <p className="text-sm text-gray-600">معدل النمو</p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-blue-600">{selectedCountryData.marketShare}%</p>
                    <p className="text-sm text-gray-600">حصة السوق</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SWOT Analysis */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="eden-card p-6">
              <h4 className="font-bold text-lg text-green-700 mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                نقاط القوة (Strengths)
              </h4>
              <ul className="space-y-2">
                {selectedCountryData.swot.strengths.map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-gray-700">
                    <span className="w-2 h-2 rounded-full bg-green-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="eden-card p-6">
              <h4 className="font-bold text-lg text-red-700 mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                نقاط الضعف (Weaknesses)
              </h4>
              <ul className="space-y-2">
                {selectedCountryData.swot.weaknesses.map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-gray-700">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="eden-card p-6">
              <h4 className="font-bold text-lg text-blue-700 mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                الفرص (Opportunities)
              </h4>
              <ul className="space-y-2">
                {selectedCountryData.swot.opportunities.map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-gray-700">
                    <span className="w-2 h-2 rounded-full bg-blue-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="eden-card p-6">
              <h4 className="font-bold text-lg text-orange-700 mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                التهديدات (Threats)
              </h4>
              <ul className="space-y-2">
                {selectedCountryData.swot.threats.map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-gray-700">
                    <span className="w-2 h-2 rounded-full bg-orange-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Requirements */}
          <div className="eden-card p-6">
            <h4 className="eden-section-title">الورقيات والمتطلبات المطلوبة</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {selectedCountryData.requirements.map((req, i) => (
                <div key={i} className="flex items-center gap-3 p-4 bg-orange-50 rounded-xl">
                  <FileCheck className="w-5 h-5 text-eden-orange" />
                  <span className="text-gray-700">{req}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Competitors */}
          <div className="eden-card p-6">
            <h4 className="eden-section-title">تحليل المنافسين</h4>
            <div className="overflow-x-auto">
              <table className="eden-table">
                <thead>
                  <tr>
                    <th>المنافس</th>
                    <th>حصة السوق</th>
                    <th>نطاق السعر</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedCountryData.competitors.map((comp, i) => (
                    <tr key={i}>
                      <td className="font-medium">{comp.name}</td>
                      <td>{comp.share}</td>
                      <td>{comp.price}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pricing */}
          <div className="eden-card p-6">
            <h4 className="eden-section-title flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              استراتيجية التسعير
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
                <p className="text-sm text-gray-600">سعر التجزئة</p>
                <p className="text-xl font-bold text-blue-700">{selectedCountryData.pricing.retail}</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
                <p className="text-sm text-gray-600">سعر الجملة</p>
                <p className="text-xl font-bold text-green-700">{selectedCountryData.pricing.wholesale}</p>
              </div>
              <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
                <p className="text-sm text-gray-600">سعر التصنيع</p>
                <p className="text-xl font-bold text-purple-700">{selectedCountryData.pricing.industrial}</p>
              </div>
            </div>
          </div>

          {/* Logistics */}
          <div className="eden-card p-6">
            <h4 className="eden-section-title flex items-center gap-2">
              <Ship className="w-5 h-5" />
              اللوجيستيات وسلاسل الإمداد
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 bg-orange-50 rounded-xl">
                <p className="text-sm text-gray-600">ميناء الوصول</p>
                <p className="font-semibold text-gray-800">{selectedCountryData.logistics.port}</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-xl">
                <p className="text-sm text-gray-600">مدة العبور</p>
                <p className="font-semibold text-gray-800">{selectedCountryData.logistics.transitTime}</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-xl">
                <p className="text-sm text-gray-600">تكلفة الشحن</p>
                <p className="font-semibold text-gray-800">{selectedCountryData.logistics.shippingCost}</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-xl">
                <p className="text-sm text-gray-600">التخزين المبرد</p>
                <p className="font-semibold text-gray-800">{selectedCountryData.logistics.coldStorage}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
