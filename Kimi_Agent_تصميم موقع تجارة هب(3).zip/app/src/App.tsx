import { useState, useEffect } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import IntroSection from './sections/IntroSection';
import HSCodesSection from './sections/HSCodesSection';
import MarketSizeSection from './sections/MarketSizeSection';
import TopImportersSection from './sections/TopImportersSection';
import CountryAnalysisSection from './sections/CountryAnalysisSection';
import CompetitorsSection from './sections/CompetitorsSection';
import DocumentsSection from './sections/DocumentsSection';
import ImportersDBSection from './sections/ImportersDBSection';
import PricingSection from './sections/PricingSection';
import LogisticsSection from './sections/LogisticsSection';
import RecommendationsSection from './sections/RecommendationsSection';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('intro');

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleSectionClick = (sectionId: string) => {
    setActiveSection(sectionId);
    setIsSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.getElementById('sidebar');
      const menuButton = document.getElementById('menu-button');
      if (
        isSidebarOpen &&
        sidebar &&
        !sidebar.contains(event.target as Node) &&
        menuButton &&
        !menuButton.contains(event.target as Node)
      ) {
        setIsSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isSidebarOpen]);

  const renderSection = () => {
    switch (activeSection) {
      case 'intro':
        return <IntroSection />;
      case 'hs-codes':
        return <HSCodesSection />;
      case 'market-size':
        return <MarketSizeSection />;
      case 'top-importers':
        return <TopImportersSection />;
      case 'country-analysis':
        return <CountryAnalysisSection />;
      case 'competitors':
        return <CompetitorsSection />;
      case 'documents':
        return <DocumentsSection />;
      case 'importers-db':
        return <ImportersDBSection />;
      case 'pricing':
        return <PricingSection />;
      case 'logistics':
        return <LogisticsSection />;
      case 'recommendations':
        return <RecommendationsSection />;
      default:
        return <IntroSection />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50/50 to-yellow-50/50">
      {/* Header */}
      <Header onMenuToggle={toggleSidebar} isSidebarOpen={isSidebarOpen} />

      {/* Sidebar */}
      <div id="sidebar">
        <Sidebar
          isOpen={isSidebarOpen}
          activeSection={activeSection}
          onSectionClick={handleSectionClick}
        />
      </div>

      {/* Main Content */}
      <main className="pt-20 pr-0 lg:pr-72 min-h-screen">
        <div className="p-4 md:p-8 max-w-7xl mx-auto">
          {/* Breadcrumb */}
          <div className="mb-6 flex items-center gap-2 text-sm text-gray-500">
            <span>الرئيسية</span>
            <span>/</span>
            <span className="text-eden-orange">
              {activeSection === 'intro' && 'المقدمة والمشهد الاستراتيجي'}
              {activeSection === 'hs-codes' && 'التحليل الفني وHS Codes'}
              {activeSection === 'market-size' && 'حجم السوق والنمو المتوقع'}
              {activeSection === 'top-importers' && 'أكبر الدول المستوردة'}
              {activeSection === 'country-analysis' && 'التحليل الداخلي للأسواق'}
              {activeSection === 'competitors' && 'تحليل المنافسين'}
              {activeSection === 'documents' && 'الورقيات المطلوبة'}
              {activeSection === 'importers-db' && 'قواعد المستوردين'}
              {activeSection === 'pricing' && 'استراتيجية التسعير'}
              {activeSection === 'logistics' && 'اللوجيستيات وسلاسل الإمداد'}
              {activeSection === 'recommendations' && 'الخاتمة والتوصيات'}
            </span>
          </div>

          {/* Section Content */}
          <div className="animate-fade-in-up">
            {renderSection()}
          </div>

          {/* Footer */}
          <footer className="mt-16 pt-8 border-t border-orange-200">
            <div className="text-center">
              <div className="flex items-center justify-center gap-4 mb-4">
                <img
                  src="https://ik.imagekit.io/tijarahub/images/logos/8/1.png"
                  alt="تجارة هب"
                  className="h-12 object-contain"
                />
              </div>
              <p className="text-gray-600 font-medium">
                خطة التصدير الاستراتيجية - إيدن جاردن
              </p>
              <p className="text-gray-500 text-sm mt-1">
                إعداد أ.د/ محمد العاصي - استشاري التجارة الدولية
              </p>
              <p className="text-gray-400 text-xs mt-4">
                © 2025 جميع الحقوق محفوظة - وحدة الاستشارات - تجارة هب
              </p>
            </div>
          </footer>
        </div>
      </main>

      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
}

export default App;
