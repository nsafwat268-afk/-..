import { 
  Code2, 
  BarChart3, 
  Globe, 
  Search, 
  Users, 
  FileText, 
  Database, 
  Tag, 
  Truck, 
  Lightbulb,
  ChevronLeft,
  Home
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  activeSection: string;
  onSectionClick: (sectionId: string) => void;
}

const menuItems = [
  { id: 'intro', label: 'المقدمة والمشهد الاستراتيجي', icon: Home },
  { id: 'hs-codes', label: 'التحليل الفني وHS Codes', icon: Code2 },
  { id: 'market-size', label: 'حجم السوق والنمو المتوقع', icon: BarChart3 },
  { id: 'top-importers', label: 'أكبر الدول المستوردة', icon: Globe },
  { id: 'country-analysis', label: 'التحليل الداخلي للأسواق', icon: Search },
  { id: 'competitors', label: 'تحليل المنافسين', icon: Users },
  { id: 'documents', label: 'الورقيات المطلوبة من مصر', icon: FileText },
  { id: 'importers-db', label: 'قواعد المستوردين', icon: Database },
  { id: 'pricing', label: 'استراتيجية التسعير', icon: Tag },
  { id: 'logistics', label: 'اللوجيستيات وسلاسل الإمداد', icon: Truck },
  { id: 'recommendations', label: 'الخاتمة والتوصيات', icon: Lightbulb },
];

export default function Sidebar({ isOpen, activeSection, onSectionClick }: SidebarProps) {
  return (
    <aside
      className={`fixed top-[60px] right-0 bottom-0 z-40 w-72 bg-white border-l border-orange-100 transition-transform duration-300 overflow-hidden ${
        isOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
      }`}
    >
      <div className="h-full overflow-y-auto">
        {/* Sidebar Header */}
        <div className="p-4 border-b border-orange-100 bg-gradient-to-r from-orange-50 to-yellow-50">
          <h3 className="font-bold text-eden-dark text-sm">قائمة المحتويات</h3>
          <p className="text-xs text-gray-500 mt-1">اختر القسم للعرض</p>
        </div>

        {/* Menu Items */}
        <nav className="p-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onSectionClick(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg mb-1 transition-all duration-300 text-right ${
                  isActive
                    ? 'bg-gradient-to-r from-eden-orange to-eden-amber text-white shadow-eden'
                    : 'hover:bg-orange-50 text-gray-700'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    isActive ? 'bg-white/20' : 'bg-orange-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-eden-orange'}`} />
                </div>
                <span className="flex-1 text-sm font-medium">{item.label}</span>
                <ChevronLeft
                  className={`w-4 h-4 transition-transform ${
                    isActive ? 'rotate-180 text-white' : 'text-gray-400'
                  }`}
                />
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-orange-100 mt-auto">
          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg p-3">
            <p className="text-xs text-gray-600 text-center">
              خطة التصدير الاستراتيجية
            </p>
            <p className="text-xs text-eden-orange font-semibold text-center mt-1">
              Eden Garden 2025
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
}
