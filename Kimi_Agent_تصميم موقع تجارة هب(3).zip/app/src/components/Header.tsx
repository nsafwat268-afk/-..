import { Menu, X } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  onMenuToggle: () => void;
  isSidebarOpen: boolean;
}

export default function Header({ onMenuToggle, isSidebarOpen }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  const handleScroll = () => {
    setIsScrolled(window.scrollY > 50);
  };

  // Add scroll listener
  if (typeof window !== 'undefined') {
    window.addEventListener('scroll', handleScroll);
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-eden'
          : 'bg-white/80 backdrop-blur-sm'
      }`}
    >
      <div className="flex items-center justify-between px-4 md:px-6 py-3">
        {/* Logo Section */}
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuToggle}
            className="p-2 rounded-lg hover:bg-orange-100 transition-colors lg:hidden"
          >
            {isSidebarOpen ? (
              <X className="w-6 h-6 text-eden-orange" />
            ) : (
              <Menu className="w-6 h-6 text-eden-orange" />
            )}
          </button>
          
          <div className="flex items-center gap-3">
            <img
              src="https://ik.imagekit.io/tijarahub/images/logos/8/1.png"
              alt="تجارة هب"
              className="h-10 md:h-12 object-contain"
            />
            <div className="hidden md:block h-8 w-px bg-gradient-to-b from-eden-orange to-eden-gold" />
            <div className="hidden md:block">
              <h1 className="text-sm font-bold text-eden-dark">
                وحدة الاستشارات
              </h1>
              <p className="text-xs text-gray-500">تجارة هب</p>
            </div>
          </div>
        </div>

        {/* Center Title */}
        <div className="flex-1 text-center px-4">
          <h2 className="text-lg md:text-xl font-bold eden-text-gradient hidden sm:block">
            خطة التصدير الاستراتيجية - إيدن جاردن
          </h2>
          <p className="text-xs text-gray-500 mt-0.5 hidden md:block">
            إعداد أ.د/ محمد العاصي - استشاري التجارة الدولية
          </p>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-3">
          <div className="hidden lg:block text-right">
            <p className="text-xs text-gray-400">المنتج مصري المنشأ</p>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-medium text-green-600">متصل</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
